# ⚔️ Fitness RPG — PWA

> Transforme seus treinos em casa em uma jornada épica de RPG.
> Funciona offline, pode ser instalado como app nativo.

---

## 🚀 Como rodar

```bash
npm install
npm start         # Desenvolvimento em http://localhost:3000
npm run build     # Build de produção (ativa o Service Worker)
```

> ⚠️ O Service Worker **só funciona em produção** (`npm run build`).
> Em desenvolvimento, use `npm start` normalmente.

---

## 📱 PWA — O que foi adicionado

| Arquivo | Descrição |
|---|---|
| `public/manifest.json` | Metadados do app (nome, ícones, cores, shortcuts) |
| `public/service-worker.js` | Cache offline, push notifications, background sync |
| `public/favicon.ico` | Favicon 32×32 |
| `public/icons/icon-*.png` | Ícones em 8 tamanhos (72→512px), maskable |
| `public/icons/icon.svg` | Ícone vetorial escalável |
| `public/icons/screenshot-mobile.png` | Screenshot para a loja de apps |
| `src/serviceWorkerRegistration.js` | Registro do SW com callbacks de update |
| `src/usePWA.js` | Hook: install prompt, online/offline, update banner |

### Estratégias de cache (Service Worker)
- **Cache-First + revalidação** → assets estáticos (JS, CSS, imagens)
- **Network-First + fallback** → navegação e dados dinâmicos
- **SPA fallback** → sempre serve `index.html` se offline

### Funcionalidades PWA
- ✅ Instalável como app (Android, iOS, Desktop)
- ✅ Funciona 100% offline após primeira visita
- ✅ Splash screen nativa enquanto carrega
- ✅ Banner de instalação in-app automático
- ✅ Banner de update quando nova versão disponível
- ✅ Banner de modo offline
- ✅ Push Notifications (base implementada)
- ✅ Background Sync (base implementada)
- ✅ Shortcuts no manifest (Missões, Ranking)
- ✅ Suporte iOS (apple-mobile-web-app-capable)
- ✅ Open Graph e Twitter Card

---

## 📁 Estrutura completa

```
fitness-rpg-full/
├── public/
│   ├── index.html                  ← Meta tags PWA completas + splash
│   ├── manifest.json               ← PWA manifest
│   ├── service-worker.js           ← SW: cache, push, sync
│   ├── favicon.ico
│   └── icons/
│       ├── icon.svg
│       ├── icon-72x72.png
│       ├── icon-96x96.png
│       ├── icon-128x128.png
│       ├── icon-144x144.png
│       ├── icon-152x152.png
│       ├── icon-192x192.png
│       ├── icon-384x384.png
│       ├── icon-512x512.png
│       └── screenshot-mobile.png
├── src/
│   ├── index.js                    ← Entry point + SW registration
│   ├── App.jsx                     ← App principal com banners PWA
│   ├── FitnessRPGv1.jsx            ← Versão anterior (batalhas RPG)
│   ├── serviceWorkerRegistration.js← Registro e callbacks do SW
│   └── usePWA.js                   ← Hook: install, online, update
├── package.json
├── .gitignore
└── README.md
```

---

## 🛠 Framework

**React 18** + hooks (`useState`, `useEffect`, `useRef`, `useCallback`).
Estilização 100% via estilos inline + CSS keyframes injetados.
**Sem bibliotecas de UI externas.**

---

## 🌐 Deploy recomendado

```bash
npm run build
# Faça deploy da pasta /build para:
# - Vercel (vercel deploy)
# - Netlify (arraste a pasta /build)
# - GitHub Pages
```

> O Service Worker requer HTTPS em produção (exceto localhost).
