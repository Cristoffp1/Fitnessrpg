// ═══════════════════════════════════════════════════════════
// Fitness RPG — usePWA Hook
// Gerencia install prompt, status online/offline e updates
// ═══════════════════════════════════════════════════════════
import { useState, useEffect, useCallback } from 'react';
import { isInstalledPWA } from './serviceWorkerRegistration';

export default function usePWA() {
  const [installPrompt, setInstallPrompt]   = useState(null);
  const [isInstalled, setIsInstalled]       = useState(false);
  const [isOnline, setIsOnline]             = useState(navigator.onLine);
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [swRegistration, setSwRegistration] = useState(null);

  useEffect(() => {
    // Detectar se já instalado
    setIsInstalled(isInstalledPWA());

    // Capturar o evento de install
    const handleBeforeInstall = (e) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    // Detectar quando foi instalado
    const handleAppInstalled = () => {
      setIsInstalled(true);
      setInstallPrompt(null);
      console.log('[PWA] App instalado com sucesso!');
    };

    // Online/Offline
    const handleOnline  = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);
    window.addEventListener('online',  handleOnline);
    window.addEventListener('offline', handleOffline);

    // Verificar SW registration para updates
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then((reg) => {
        setSwRegistration(reg);
        reg.onupdatefound = () => setUpdateAvailable(true);
      });

      // Listener para mensagens do SW
      navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data?.type === 'NEW_VERSION') setUpdateAvailable(true);
      });
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('online',  handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Disparar o prompt de instalação
  const promptInstall = useCallback(async () => {
    if (!installPrompt) return false;
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === 'accepted') setIsInstalled(true);
    setInstallPrompt(null);
    return outcome === 'accepted';
  }, [installPrompt]);

  // Aplicar update disponível
  const applyUpdate = useCallback(() => {
    if (!swRegistration?.waiting) return;
    swRegistration.waiting.postMessage({ type: 'SKIP_WAITING' });
    window.location.reload();
  }, [swRegistration]);

  return {
    canInstall: !!installPrompt && !isInstalled,
    isInstalled,
    isOnline,
    updateAvailable,
    promptInstall,
    applyUpdate,
  };
}
