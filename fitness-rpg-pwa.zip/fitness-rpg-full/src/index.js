import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { register } from './serviceWorkerRegistration';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Registrar Service Worker com callbacks
register({
  onSuccess: (registration) => {
    console.log('[PWA] ✅ App pronto para uso offline!', registration);
  },
  onUpdate: (registration) => {
    console.log('[PWA] 🔄 Nova versão disponível!', registration);
    // O hook usePWA() detecta automaticamente via onupdatefound
  },
});
