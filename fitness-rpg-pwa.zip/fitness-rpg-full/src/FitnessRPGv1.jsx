import { useState, useEffect, useRef } from "react";

// ─── DATA ────────────────────────────────────────────────────────────────────

const MUSCLE_GROUPS = {
  peito:  { name: "Peito",  emoji: "💪", color: "#ff6644" },
  pernas: { name: "Pernas", emoji: "🦵", color: "#22c55e" },
  core:   { name: "Core",   emoji: "🔥", color: "#f59e0b" },
  cardio: { name: "Cardio", emoji: "⚡", color: "#00aaff" },
  costas: { name: "Costas", emoji: "🛡️", color: "#a855f7" },
};

const EXERCISES = [
  { id:1, name:"Flexões",      emoji:"💪", group:"peito",  intensity:2, xp:30, damage:45, type:"attack",  tip:"Mantenha o corpo reto como uma tábua" },
  { id:2, name:"Agachamentos", emoji:"🦵", group:"pernas", intensity:2, xp:25, damage:35, type:"attack",  tip:"Joelhos não passam dos pés" },
  { id:3, name:"Abdominais",   emoji:"🔥", group:"core",   intensity:1, xp:20, damage:25, type:"attack",  tip:"Expire na subida, não force o pescoço" },
  { id:4, name:"Burpees",      emoji:"⚡", group:"cardio", intensity:3, xp:50, damage:70, type:"special", tip:"Ritmo constante — qualidade > velocidade" },
  { id:5, name:"Prancha",      emoji:"🛡️", group:"core",   intensity:1, xp:15, damage:0,  type:"defend",  tip:"Respire normalmente, não prenda o ar" },
  { id:6, name:"Polichinelos", emoji:"✨", group:"cardio", intensity:1, xp:20, damage:20, type:"magic",   tip:"Aterrisse suavemente no calcanhar" },
  { id:7, name:"Afundo",       emoji:"🦵", group:"pernas", intensity:2, xp:28, damage:38, type:"attack",  tip:"Joelho traseiro quase toca o chão" },
  { id:8, name:"Superman",     emoji:"🦸", group:"costas", intensity:1, xp:18, damage:22, type:"magic",   tip:"Eleve devagar, sem travar o pescoço" },
];

const BASE_REPS     = { 1:8, 2:12, 3:15, 4:4, 5:20, 6:20, 7:10, 8:10 };
const BASE_DURATION = { 5:20 };

const ENEMIES = [
  { name:"Goblin Preguiçoso", emoji:"👺", hp:100, maxHp:100, atk:12, level:1, reward:80 },
  { name:"Ogro Sedentário",   emoji:"👹", hp:180, maxHp:180, atk:22, level:3, reward:180 },
  { name:"Dragão Cansado",    emoji:"🐉", hp:300, maxHp:300, atk:35, level:6, reward:360 },
  { name:"Lich do Sofá",      emoji:"💀", hp:450, maxHp:450, atk:50, level:10,reward:600 },
];

const WEEKLY_PLAN = [
  ["cardio","core"],
  ["peito","core"],
  ["pernas"],
  ["costas","cardio"],
  ["pernas","core"],
  ["peito","costas"],
  ["cardio"],
];

// ─── MISSÕES ────────────────────────────────────────────────────────────────
// Cada missão tem tipo, condição e recompensa
const MISSION_POOL = [
  { id:"m1",  icon:"🔥", title:"Sem Parar",      desc:"Complete 3 exercícios em sequência sem cancelar",  type:"sequence",  target:3,   reward:{xp:60,  gold:30},  rarity:"comum"  },
  { id:"m2",  icon:"⚡", title:"Velocista",       desc:"Complete um exercício de cardio hoje",              type:"group",     target:"cardio", reward:{xp:40, gold:20}, rarity:"comum"  },
  { id:"m3",  icon:"💪", title:"Força Bruta",     desc:"Complete 2 exercícios de peito",                   type:"groupCount",target:{group:"peito",count:2},  reward:{xp:70,gold:35}, rarity:"raro"   },
  { id:"m4",  icon:"🛡️", title:"Guardião",        desc:"Use a Prancha 2 vezes",                            type:"exCount",   target:{id:5,count:2},           reward:{xp:50,gold:25}, rarity:"comum"  },
  { id:"m5",  icon:"💥", title:"Crítico!",        desc:"Cause um golpe crítico em batalha",                type:"crit",      target:1,   reward:{xp:80,  gold:40},  rarity:"raro"   },
  { id:"m6",  icon:"🏆", title:"Vencedor",        desc:"Derrote 1 inimigo",                               type:"wins",      target:1,   reward:{xp:60,  gold:50},  rarity:"comum"  },
  { id:"m7",  icon:"🦵", title:"Pernas de Aço",  desc:"Complete 2 exercícios de pernas",                  type:"groupCount",target:{group:"pernas",count:2}, reward:{xp:70,gold:35}, rarity:"raro"   },
  { id:"m8",  icon:"🌟", title:"Polivalente",     desc:"Faça exercícios de 3 grupos musculares diferentes",type:"variety",   target:3,   reward:{xp:100, gold:60},  rarity:"épico"  },
  { id:"m9",  icon:"🔋", title:"Econômico",       desc:"Complete uma batalha com mais de 50 de energia",   type:"energy",    target:50,  reward:{xp:50,  gold:25},  rarity:"comum"  },
  { id:"m10", icon:"🎯", title:"Sem Falhas",      desc:"Derrote um inimigo sem tomar dano",               type:"nodamage",  target:1,   reward:{xp:120, gold:80},  rarity:"épico"  },
];

const RARITY_COLORS = { comum:"#8888cc", raro:"#00aaff", épico:"#ffd700" };
const RARITY_BG     = { comum:"#0a0a22", raro:"#001a2a", épico:"#1a1400" };

// ─── TUTORIAL STEPS ──────────────────────────────────────────────────────────
const TUTORIAL_STEPS = [
  {
    emoji:"⚔️", title:"Bem-vindo ao Fitness RPG!",
    text:"Aqui você treina de verdade para vencer batalhas. Cada exercício que você faz vira um ataque — quanto melhor sua forma, mais forte seu golpe!",
    highlight: null,
  },
  {
    emoji:"👺", title:"Como funciona a batalha",
    text:"Você enfrenta inimigos em turnos. Escolha um exercício, complete as reps, e seu personagem ataca automaticamente. O inimigo contra-ataca — mas você pode se defender!",
    visual: "battle",
  },
  {
    emoji:"⚡", title:"Energia do Dia",
    text:"Você tem 100 pontos de energia por dia. Cada exercício consome energia — exercícios intensos consomem mais. Quando acabar, descanse até amanhã para evitar lesões!",
    visual: "energy",
  },
  {
    emoji:"😴", title:"Descanso Muscular",
    text:"Exercícios do mesmo grupo muscular precisam de pausa entre si. Depois de fazer Flexões (Peito), alterne para outro grupo antes de repetir — isso previne lesões reais!",
    visual: "cooldown",
  },
  {
    emoji:"🗺️", title:"Missão do Dia",
    text:"Todo dia há uma rotação de grupos musculares recomendados. Seguir o plano garante equilíbrio corporal e bônus de XP extra ao completar!",
    visual: "mission",
  },
  {
    emoji:"🎯", title:"Missões Especiais",
    text:"Além das missões diárias, você recebe 3 desafios aleatórios com recompensas de XP e ouro. Complete-os para evoluir mais rápido e desbloquear recompensas épicas!",
    visual: "quests",
  },
  {
    emoji:"📈", title:"Evolução Segura",
    text:"Seu nível aumenta conforme você treina. As reps crescem com você — mas sempre com teto seguro por tipo de exercício. Progresso sem exagero!",
    visual: "level",
  },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

function getTodayGroups() { return WEEKLY_PLAN[new Date().getDay()]; }

function getRepsForLevel(exId, level) {
  const base = BASE_REPS[exId] || 10;
  const ex = EXERCISES.find(e => e.id === exId);
  const maxReps = ex?.intensity === 3 ? 8 : ex?.intensity === 2 ? 20 : 30;
  return Math.min(base + Math.floor((level - 1) / 2), maxReps);
}

function getDurationForLevel(exId, level) {
  return Math.min((BASE_DURATION[exId] || 20) + (level - 1) * 2, 60);
}

function energyCostOf(ex) { return ex.intensity * 12; }

function pickDailyMissions(seed) {
  const rng = (n) => { let x = Math.sin(seed + n) * 10000; return x - Math.floor(x); };
  const shuffled = [...MISSION_POOL].sort((a, b) => rng(a.id.charCodeAt(1)) - rng(b.id.charCodeAt(1)));
  return shuffled.slice(0, 3);
}

// ─── COMPONENTS ──────────────────────────────────────────────────────────────

function HealthBar({ current, max, color = "#22c55e" }) {
  const pct = Math.max(0, Math.min(100, (current / max) * 100));
  return (
    <div style={{ background:"#0d0d22", borderRadius:8, height:12, overflow:"hidden", border:"1px solid #2a2a4a", width:"100%" }}>
      <div style={{ width:`${pct}%`, height:"100%", background:`linear-gradient(90deg,${color}cc,${color})`, borderRadius:8, transition:"width 0.5s ease", boxShadow:`0 0 6px ${color}88` }} />
    </div>
  );
}

function FloatingText({ texts }) {
  return (
    <div style={{ position:"absolute", inset:0, pointerEvents:"none", overflow:"hidden", zIndex:50 }}>
      {texts.map(t => (
        <div key={t.id} style={{ position:"absolute", left:`${t.x}%`, top:`${t.y}%`, color:t.color||"#ffd700", fontWeight:900, fontSize:t.size||22, fontFamily:"monospace", animation:"floatUp 1.4s ease-out forwards", textShadow:`0 0 12px ${t.color||"#ffd700"}`, whiteSpace:"nowrap" }}>
          {t.text}
        </div>
      ))}
    </div>
  );
}

function EnergyBar({ current, max }) {
  const pct = (current / max) * 100;
  const color = pct > 60 ? "#22c55e" : pct > 30 ? "#f59e0b" : "#ef4444";
  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
        <span style={{ fontSize:11, color:"#8888bb", fontWeight:700 }}>⚡ ENERGIA DO DIA</span>
        <span style={{ fontSize:11, color, fontWeight:800 }}>{current}/{max}</span>
      </div>
      <HealthBar current={current} max={max} color={color} />
      {pct <= 20 && <div style={{ fontSize:11, color:"#ff8866", marginTop:4, fontWeight:700 }}>⚠️ Energia baixa — descanse!</div>}
    </div>
  );
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────

export default function FitnessRPG() {
  const [screen, setScreen] = useState("tutorial"); // tutorial | home | missions | battle | exercise | victory | defeat | levelup
  const [tutorialStep, setTutorialStep] = useState(0);

  const [player, setPlayer] = useState({
    name:"Guerreiro", level:1, xp:0, xpNeeded:100,
    hp:100, maxHp:100, gold:0, wins:0, totalWorkouts:0,
    streak:0, lastPlayedDay:null, noDamageRun:true,
  });

  const [session, setSession] = useState({
    energy:100, maxEnergy:100,
    doneTodayKey:null,
    groupCooldowns:{},
    completedInSession:[],
    groupsDoneInSession:{},   // group -> count
    sequenceCount:0,
    critHit:false,
    missionsToday:[], missionsCompleted:[],
    // quests
    dailyMissions:[], questProgress:{}, questCompleted:[],
  });

  const [enemy, setEnemy]           = useState(null);
  const [enemyIdx, setEnemyIdx]     = useState(0);
  const [activeExercise, setActiveExercise] = useState(null);
  const [reps, setReps]             = useState(0);
  const [timer, setTimer]           = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [floats, setFloats]         = useState([]);
  const [log, setLog]               = useState([]);
  const [shake, setShake]           = useState(false);
  const [defending, setDefending]   = useState(false);
  const [showTip, setShowTip]       = useState(false);
  const [warningMsg, setWarningMsg] = useState(null);
  const [newQuestMsg, setNewQuestMsg] = useState(null);

  const timerRef           = useRef(null);
  const floatId            = useRef(0);
  const exerciseCompleted  = useRef(false);

  // Init sessão do dia
  useEffect(() => {
    const key = todayKey();
    if (session.doneTodayKey !== key) {
      const seed = parseInt(key.replace(/-/g,""));
      const missions = pickDailyMissions(seed);
      setSession(s => ({
        ...s,
        energy:100, doneTodayKey:key,
        groupCooldowns:{}, completedInSession:[],
        groupsDoneInSession:{}, sequenceCount:0, critHit:false,
        missionsToday:getTodayGroups(), missionsCompleted:[],
        dailyMissions:missions, questProgress:{}, questCompleted:[],
      }));
      setPlayer(p => {
        const todayStr = new Date().toDateString();
        const yestStr  = new Date(Date.now()-86400000).toDateString();
        const streak = p.lastPlayedDay===yestStr ? p.streak+1 : p.lastPlayedDay===todayStr ? p.streak : 1;
        return { ...p, streak, lastPlayedDay:todayStr };
      });
    }
    return () => clearInterval(timerRef.current);
  }, []);

  // ── helpers ──
  function addFloat(text,color,x=50,y=30,size=22) {
    const id=floatId.current++;
    setFloats(f=>[...f,{id,text,color,x,y,size}]);
    setTimeout(()=>setFloats(f=>f.filter(t=>t.id!==id)),1500);
  }
  function addLog(msg,color="#aaaacc") {
    setLog(l=>[{msg,color,id:Date.now()+Math.random()},...l].slice(0,5));
  }
  function showWarning(msg) { setWarningMsg(msg); setTimeout(()=>setWarningMsg(null),2800); }
  function showQuestMsg(msg){ setNewQuestMsg(msg); setTimeout(()=>setNewQuestMsg(null),2500); }

  function canDoExercise(ex) {
    const cost = energyCostOf(ex);
    if (session.energy < cost) return { ok:false, reason:`⚡ Energia insuficiente! Custo: ${cost}` };
    const cd = session.groupCooldowns[ex.group] || 0;
    if (cd > 0) {
      const g = MUSCLE_GROUPS[ex.group];
      return { ok:false, reason:`${g.emoji} ${g.name} descansando — ${cd} exercício(s) restante(s)` };
    }
    return { ok:true };
  }

  function pickExercise(ex) {
    const check = canDoExercise(ex);
    if (!check.ok) { showWarning(check.reason); return; }
    setActiveExercise(ex);
    setReps(0); setTimer(0); setIsTimerRunning(false); setShowTip(false);
    exerciseCompleted.current = false;
    clearInterval(timerRef.current);
    if (ex.type==="defend") {
      setIsTimerRunning(true);
      timerRef.current = setInterval(()=>setTimer(t=>t+1),1000);
    }
    setScreen("exercise");
  }

  function startBattle() {
    const e = { ...ENEMIES[enemyIdx] };
    setEnemy(e); setLog([]); setDefending(false);
    setPlayer(p=>({...p,noDamageRun:true}));
    setScreen("battle");
  }

  function addRep() {
    const required = getRepsForLevel(activeExercise.id, player.level);
    const next = reps+1;
    setReps(next);
    if (next >= required) setTimeout(completeExercise, 200);
  }

  // ── Checar progresso de missões ──
  function checkQuestProgress(ex, isCrit, newGroupsDone, sequenceCount, winsTotal, noDmg, energyLeft, newQuestCompleted, newQuestProgress) {
    const missions = session.dailyMissions;
    missions.forEach(m => {
      if (newQuestCompleted.includes(m.id)) return;
      let prog = newQuestProgress[m.id] || 0;
      let completed = false;
      if      (m.type==="sequence"   && sequenceCount >= m.target)                           completed=true;
      else if (m.type==="group"      && ex.group===m.target)                                 { prog=1; completed=true; }
      else if (m.type==="groupCount" && ex.group===m.target.group)                           { prog=Math.min((prog||0)+1,m.target.count); completed=prog>=m.target.count; }
      else if (m.type==="exCount"    && ex.id===m.target.id)                                 { prog=Math.min((prog||0)+1,m.target.count); completed=prog>=m.target.count; }
      else if (m.type==="crit"       && isCrit)                                              completed=true;
      else if (m.type==="wins"       && winsTotal >= m.target)                               completed=true;
      else if (m.type==="variety"    && Object.keys(newGroupsDone).length >= m.target)       completed=true;
      else if (m.type==="energy"     && energyLeft >= m.target)                              completed=true;
      else if (m.type==="nodamage"   && noDmg)                                               completed=true;
      newQuestProgress[m.id] = prog;
      if (completed) {
        newQuestCompleted.push(m.id);
        showQuestMsg(`🎯 Missão completa: ${m.title}! +${m.reward.xp}XP +${m.reward.gold}💰`);
      }
    });
  }

  function completeExercise() {
    if (exerciseCompleted.current) return;
    exerciseCompleted.current = true;
    clearInterval(timerRef.current);

    const ex      = activeExercise;
    const cost    = energyCostOf(ex);
    const newEnergy = Math.max(0, session.energy - cost);

    // Cooldown
    const cdVal = ex.intensity >= 2 ? ex.intensity-1 : 0;
    const newCooldowns = {};
    Object.keys(session.groupCooldowns).forEach(g=>{
      const v = session.groupCooldowns[g]-1;
      if (v>0) newCooldowns[g]=v;
    });
    if (cdVal>0) newCooldowns[ex.group]=cdVal;

    // Missões do dia
    const newMissionsCompleted = [...session.missionsCompleted];
    if (session.missionsToday.includes(ex.group) && !newMissionsCompleted.includes(ex.group))
      newMissionsCompleted.push(ex.group);

    // Grupos feitos nessa sessão
    const newGroupsDone = { ...session.groupsDoneInSession };
    newGroupsDone[ex.group] = (newGroupsDone[ex.group]||0)+1;

    // Sequência
    const newSeq = session.sequenceCount + 1;

    // Dano
    let dmg    = ex.damage;
    const isCrit = Math.random() < 0.18;
    if (isCrit) dmg = Math.floor(dmg*1.75);
    const isBlock  = ex.type==="defend";
    const enemyAtk = defending ? 0 : Math.floor((enemy?.atk||20)*(0.6+Math.random()*0.8));

    let newEnemyHp  = enemy ? enemy.hp : 0;
    let newPlayerHp = player.hp;

    if (isBlock) {
      const heal = Math.floor(12+Math.random()*12);
      newPlayerHp = Math.min(player.maxHp, player.hp+heal);
      addFloat(`+${heal} ❤️`,"#22c55e",18,55,18);
      addLog(`🛡️ Defendeu! Recuperou ${heal} HP`,"#22c55e");
    } else {
      newEnemyHp = Math.max(0,(enemy?.hp||0)-dmg);
      if (isCrit) { addFloat(`💥 CRÍTICO -${dmg}`,"#ff4444",55,18,26); addLog(`💥 CRÍTICO! ${dmg} dano!`,"#ff4444"); }
      else        { addFloat(`⚔️ -${dmg}`,"#ffd700",58,22,22);         addLog(`⚔️ Causou ${dmg} dano!`,"#ffd700"); }
    }

    let tookDamage = false;
    if (!isBlock && enemy && newEnemyHp>0) {
      newPlayerHp = Math.max(0, newPlayerHp-enemyAtk);
      tookDamage = true;
      setShake(true); setTimeout(()=>setShake(false),500);
      addFloat(`💔 -${enemyAtk}`,"#ff6666",18,28,18);
      addLog(`👹 ${enemy.name} atacou! -${enemyAtk} HP`,"#ff6666");
    }
    const noDmgNow = player.noDamageRun && !tookDamage;

    // XP
    let newXp = player.xp + ex.xp;
    let newLevel = player.level, newXpNeeded = player.xpNeeded, newMaxHp = player.maxHp;
    let leveled = false;
    while (newXp >= newXpNeeded) {
      newXp -= newXpNeeded; newLevel++; newXpNeeded=Math.floor(newXpNeeded*1.4); newMaxHp+=15; leveled=true;
    }

    const newWins = enemy && newEnemyHp<=0 ? player.wins+1 : player.wins;

    // Quest progress
    const newQuestCompleted = [...session.questCompleted];
    const newQuestProgress  = { ...session.questProgress };
    checkQuestProgress(ex, isCrit, newGroupsDone, newSeq, newWins, noDmgNow, newEnergy, newQuestCompleted, newQuestProgress);

    // Quest XP/gold bonus
    const newlyCompleted = newQuestCompleted.filter(id=>!session.questCompleted.includes(id));
    let bonusXp=0, bonusGold=0;
    newlyCompleted.forEach(id=>{
      const m = MISSION_POOL.find(m=>m.id===id);
      if(m){ bonusXp+=m.reward.xp; bonusGold+=m.reward.gold; }
    });
    newXp += bonusXp;
    while (newXp >= newXpNeeded) { newXp-=newXpNeeded; newLevel++; newXpNeeded=Math.floor(newXpNeeded*1.4); newMaxHp+=15; leveled=true; }

    setSession(s=>({
      ...s,
      energy: newEnergy, groupCooldowns: newCooldowns,
      completedInSession:[...s.completedInSession,ex.id],
      groupsDoneInSession: newGroupsDone,
      sequenceCount: newSeq,
      critHit: s.critHit||isCrit,
      missionsCompleted: newMissionsCompleted,
      questCompleted: newQuestCompleted,
      questProgress: newQuestProgress,
    }));

    setDefending(isBlock);
    if (enemy) setEnemy(e=>({...e,hp:newEnemyHp}));
    setPlayer(p=>({
      ...p, hp:newPlayerHp, xp:newXp, xpNeeded:newXpNeeded,
      level:newLevel, maxHp:newMaxHp,
      totalWorkouts:p.totalWorkouts+1,
      wins:newWins,
      gold:p.gold+bonusGold+(enemy&&newEnemyHp<=0?(enemy?.reward||100):0),
      noDamageRun:noDmgNow,
    }));

    if (enemy && newEnemyHp<=0) {
      addLog(`🏆 Vitória! +${enemy?.reward} ouro`,"#ffd700");
      setTimeout(()=>{ setEnemyIdx(i=>(i+1)%ENEMIES.length); setScreen(leveled?"levelup":"victory"); },500);
    } else if (newPlayerHp<=0) {
      setTimeout(()=>setScreen("defeat"),500);
    } else {
      setScreen(leveled?"levelup":"battle");
    }
  }

  useEffect(()=>{
    if (isTimerRunning && activeExercise?.type==="defend" && !exerciseCompleted.current) {
      const req = getDurationForLevel(activeExercise.id, player.level);
      if (timer>=req) { setIsTimerRunning(false); clearInterval(timerRef.current); completeExercise(); }
    }
  },[timer]);

  // ── Styles ──────────────────────────────────────────────────────────────────
  const S = {
    app: {
      minHeight:"100vh", background:"#080818",
      fontFamily:"'Segoe UI',system-ui,sans-serif", color:"#e0e0ff",
      display:"flex", flexDirection:"column", alignItems:"center", paddingBottom:48,
      backgroundImage:"radial-gradient(ellipse at 15% 15%,#1a0a2e 0%,transparent 55%),radial-gradient(ellipse at 85% 85%,#0a1830 0%,transparent 55%)"
    },
    card: {
      background:"linear-gradient(135deg,#0f0f28 0%,#161630 100%)",
      border:"1px solid #2a2a5544", borderRadius:20, padding:"18px",
      width:"100%", maxWidth:460, boxShadow:"0 8px 32px #00003366",
    },
    btn:(c="#6644ff",small=false)=>({
      background:`linear-gradient(135deg,${c}dd,${c}88)`,
      border:`1px solid ${c}88`, borderRadius:14,
      padding:small?"10px 16px":"13px 20px",
      color:"#fff", fontWeight:800, fontSize:small?13:15,
      cursor:"pointer", width:"100%", margin:"4px 0",
      boxShadow:`0 0 16px ${c}33`, fontFamily:"inherit", letterSpacing:0.3,
    }),
    label:{ fontSize:11, color:"#6666aa", letterSpacing:1.5, textTransform:"uppercase", marginBottom:4, fontWeight:700 },
  };

  const CSS = `
    @keyframes floatUp{0%{opacity:1;transform:translateY(0)}100%{opacity:0;transform:translateY(-70px)}}
    @keyframes shake{0%,100%{transform:translateX(0)}25%,75%{transform:translateX(-8px)}50%{transform:translateX(8px)}}
    @keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
    @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.05)}}
    @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
    @keyframes slideIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
    @keyframes shimmer{0%,100%{opacity:0.7}50%{opacity:1}}
    @keyframes glow{0%,100%{box-shadow:0 0 10px #6644ff44}50%{box-shadow:0 0 24px #6644ffaa}}
    @keyframes fadeIn{from{opacity:0}to{opacity:1}}
    @keyframes popIn{from{opacity:0;transform:scale(0.8)}to{opacity:1;transform:scale(1)}}
  `;

  // ════════════════════════════════════════════════════════════
  // TUTORIAL
  // ════════════════════════════════════════════════════════════
  if (screen==="tutorial") {
    const step = TUTORIAL_STEPS[tutorialStep];
    const isLast = tutorialStep === TUTORIAL_STEPS.length-1;

    const visuals = {
      battle: (
        <div style={{ display:"flex", justifyContent:"center", gap:24, alignItems:"center", padding:"12px 0" }}>
          <div style={{ textAlign:"center" }}>
            <div style={{ fontSize:40 }}>👺</div>
            <div style={{ fontSize:10, color:"#ff8888" }}>Inimigo</div>
            <div style={{ background:"#1a0000", border:"1px solid #ff444433", borderRadius:8, padding:"4px 10px", fontSize:11, color:"#ff6666", marginTop:4 }}>HP ██████░░</div>
          </div>
          <div style={{ fontSize:28, color:"#ffd700" }}>⚔️</div>
          <div style={{ textAlign:"center" }}>
            <div style={{ fontSize:40 }}>🧙</div>
            <div style={{ fontSize:10, color:"#88aaff" }}>Você</div>
            <div style={{ background:"#00001a", border:"1px solid #6644ff33", borderRadius:8, padding:"4px 10px", fontSize:11, color:"#8888ff", marginTop:4 }}>HP ████████</div>
          </div>
        </div>
      ),
      energy: (
        <div style={{ padding:"12px 0" }}>
          {[["100","Energia cheia — treino completo!","#22c55e",100],
            ["50","Metade — cuidado!","#f59e0b",50],
            ["10","Esgotada — descanse!","#ef4444",10]
          ].map(([val,label,color,pct])=>(
            <div key={val} style={{ marginBottom:8 }}>
              <div style={{ display:"flex", justifyContent:"space-between", fontSize:11, marginBottom:3 }}>
                <span style={{ color:"#8888aa" }}>{label}</span>
                <span style={{ color, fontWeight:700 }}>{val}</span>
              </div>
              <div style={{ background:"#0d0d22", borderRadius:6, height:8, overflow:"hidden" }}>
                <div style={{ width:`${pct}%`, height:"100%", background:`linear-gradient(90deg,${color}cc,${color})`, borderRadius:6 }} />
              </div>
            </div>
          ))}
        </div>
      ),
      cooldown: (
        <div style={{ padding:"8px 0" }}>
          {[{name:"Flexões",emoji:"💪",group:"Peito",ok:false,cd:1},{name:"Agachamentos",emoji:"🦵",group:"Pernas",ok:true},{name:"Abdominais",emoji:"🔥",group:"Core",ok:true}].map(e=>(
            <div key={e.name} style={{ display:"flex", alignItems:"center", gap:10, background:e.ok?"#0a1a0a":"#1a0a0a", border:`1px solid ${e.ok?"#22c55e33":"#ff444433"}`, borderRadius:10, padding:"8px 12px", marginBottom:6 }}>
              <span style={{ fontSize:22 }}>{e.emoji}</span>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:13, fontWeight:700 }}>{e.name}</div>
                <div style={{ fontSize:10, color:"#666688" }}>{e.group}</div>
              </div>
              <div style={{ fontSize:11, fontWeight:700, color:e.ok?"#22c55e":"#ff6644" }}>
                {e.ok ? "✅ Livre" : `😴 Descanso: ${e.cd} ex.`}
              </div>
            </div>
          ))}
        </div>
      ),
      mission: (
        <div style={{ padding:"8px 0" }}>
          {[{g:"peito",done:true},{g:"core",done:true},{g:"cardio",done:false}].map(({g,done})=>{
            const info=MUSCLE_GROUPS[g];
            return (
              <div key={g} style={{ display:"flex", alignItems:"center", gap:10, background:done?"#0a1a0a":"#0a0a1e", border:`1px solid ${done?"#22c55e44":"#33335544"}`, borderRadius:10, padding:"8px 12px", marginBottom:6 }}>
                <span style={{ fontSize:22 }}>{done?"✅":info.emoji}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13, fontWeight:700, color:done?"#22c55e":"#e0e0ff" }}>{info.name}</div>
                </div>
                <span style={{ fontSize:11, color:done?"#22c55e":"#6644ff" }}>{done?"Feito!":"Pendente"}</span>
              </div>
            );
          })}
        </div>
      ),
      quests: (
        <div style={{ padding:"8px 0" }}>
          {[{icon:"🔥",title:"Sem Parar",prog:2,max:3,rarity:"comum"},{icon:"💥",title:"Crítico!",prog:0,max:1,rarity:"raro"},{icon:"🌟",title:"Polivalente",prog:1,max:3,rarity:"épico"}].map(q=>(
            <div key={q.title} style={{ background:RARITY_BG[q.rarity], border:`1px solid ${RARITY_COLORS[q.rarity]}33`, borderRadius:10, padding:"8px 12px", marginBottom:6 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                <span style={{ fontSize:13, fontWeight:700 }}>{q.icon} {q.title}</span>
                <span style={{ fontSize:10, color:RARITY_COLORS[q.rarity], fontWeight:700 }}>{q.rarity}</span>
              </div>
              <div style={{ background:"#0d0d22", borderRadius:4, height:6, overflow:"hidden" }}>
                <div style={{ width:`${(q.prog/q.max)*100}%`, height:"100%", background:RARITY_COLORS[q.rarity] }} />
              </div>
              <div style={{ fontSize:10, color:"#6666aa", marginTop:3 }}>{q.prog}/{q.max}</div>
            </div>
          ))}
        </div>
      ),
      level: (
        <div style={{ textAlign:"center", padding:"8px 0" }}>
          <div style={{ display:"flex", justifyContent:"center", gap:16, marginBottom:12 }}>
            {[1,2,3,5,8].map(lv=>(
              <div key={lv} style={{ background:lv<=3?"#1a1040":"#0a0a1e", border:`1px solid ${lv<=3?"#6644ff88":"#33335544"}`, borderRadius:10, padding:"8px 10px", textAlign:"center", minWidth:44 }}>
                <div style={{ fontSize:11, color:"#8888aa" }}>Nv.</div>
                <div style={{ fontSize:18, fontWeight:900, color:lv<=3?"#c8b8ff":"#555577" }}>{lv}</div>
              </div>
            ))}
          </div>
          <div style={{ fontSize:12, color:"#8888cc" }}>Reps crescem com você — de forma segura!</div>
        </div>
      ),
    };

    return (
      <div style={S.app}>
        <style>{CSS}</style>
        <div style={{ width:"100%", maxWidth:460, padding:"30px 16px" }}>

          {/* Indicador de passos */}
          <div style={{ display:"flex", justifyContent:"center", gap:6, marginBottom:24 }}>
            {TUTORIAL_STEPS.map((_,i)=>(
              <div key={i} style={{
                width: i===tutorialStep?24:8, height:8, borderRadius:4,
                background: i===tutorialStep?"#6644ff": i<tutorialStep?"#44337788":"#222244",
                transition:"all 0.3s ease"
              }} />
            ))}
          </div>

          <div style={{ ...S.card, animation:"popIn 0.35s ease", textAlign:"center" }}>
            <div style={{ fontSize:64, marginBottom:12, animation:"pulse 2s ease-in-out infinite", filter:"drop-shadow(0 0 20px #6644ff66)" }}>
              {step.emoji}
            </div>
            <div style={{ fontSize:20, fontWeight:900, color:"#c8b8ff", marginBottom:10 }}>{step.title}</div>
            <div style={{ fontSize:14, color:"#9999cc", lineHeight:1.6, marginBottom:16 }}>{step.text}</div>

            {step.visual && visuals[step.visual] && (
              <div style={{ background:"#07071a", border:"1px solid #2a2a4444", borderRadius:14, padding:"8px 12px", marginBottom:16, animation:"fadeIn 0.4s ease" }}>
                {visuals[step.visual]}
              </div>
            )}

            <div style={{ display:"grid", gridTemplateColumns: tutorialStep>0?"1fr 1fr":"1fr", gap:10, marginTop:8 }}>
              {tutorialStep>0 && (
                <button onClick={()=>setTutorialStep(t=>t-1)} style={{ ...S.btn("#333355"), fontSize:14 }}>
                  ← Anterior
                </button>
              )}
              <button onClick={()=>{ if(isLast){setScreen("home");}else{setTutorialStep(t=>t+1);}}}
                style={{ ...S.btn(isLast?"#22c55e":"#6644ff"), fontSize:14, animation:isLast?"glow 2s infinite":"none" }}>
                {isLast ? "🚀 Começar a jogar!" : "Próximo →"}
              </button>
            </div>

            {!isLast && (
              <button onClick={()=>setScreen("home")} style={{ background:"none", border:"none", color:"#444466", fontSize:11, cursor:"pointer", marginTop:10, fontFamily:"inherit" }}>
                Pular tutorial
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════
  // HOME
  // ════════════════════════════════════════════════════════════
  if (screen==="home") {
    const todayGroups = getTodayGroups();
    const allDayDone  = todayGroups.every(g=>session.missionsCompleted.includes(g));
    const questsDone  = session.questCompleted.length;
    const questsTotal = session.dailyMissions.length;

    return (
      <div style={S.app}>
        <style>{CSS}</style>
        <div style={{ width:"100%", maxWidth:460, padding:"24px 16px 0" }}>

          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
            <div>
              <div style={{ fontSize:22, fontWeight:900, color:"#c8b8ff" }}>⚔️ FITNESS RPG</div>
              <div style={{ fontSize:11, color:"#5555aa" }}>Treine. Evolua. Conquiste.</div>
            </div>
            <div style={{ display:"flex", gap:8 }}>
              <button onClick={()=>setScreen("tutorial")} style={{ background:"#111130", border:"1px solid #33335544", borderRadius:10, color:"#8888cc", padding:"6px 10px", cursor:"pointer", fontSize:12, fontFamily:"inherit" }}>❓</button>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontSize:20, fontWeight:900, color:"#ffd700" }}>Nv.{player.level}</div>
                <div style={{ fontSize:11, color:"#8888cc" }}>🔥 {player.streak}d</div>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div style={{ ...S.card, marginBottom:12 }}>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8, marginBottom:14 }}>
              {[["❤️","HP",player.hp,player.maxHp,"#ef4444"],["⚡","XP",player.xp,player.xpNeeded,"#6644ff"],["💰","Ouro",player.gold,null,"#ffd700"]].map(([ico,lbl,val,max,c])=>(
                <div key={lbl} style={{ background:"#0a0a1e", borderRadius:12, padding:"10px 6px", textAlign:"center", border:`1px solid ${c}22` }}>
                  <div style={{ fontSize:11, color:"#5555aa" }}>{ico} {lbl}</div>
                  <div style={{ fontWeight:900, color:c, fontSize:15 }}>{val}{max?`/${max}`:""}</div>
                </div>
              ))}
            </div>
            <EnergyBar current={session.energy} max={session.maxEnergy} />
          </div>

          {/* Missão do Dia */}
          <div style={{ ...S.card, marginBottom:12, border:allDayDone?"1px solid #ffd70044":"1px solid #2a2a5544" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
              <div style={S.label}>🗺️ PLANO DE HOJE</div>
              {allDayDone && <div style={{ fontSize:11, color:"#ffd700", fontWeight:800, animation:"shimmer 2s infinite" }}>✅ COMPLETO!</div>}
            </div>
            {todayGroups.map(g=>{
              const info=MUSCLE_GROUPS[g], done=session.missionsCompleted.includes(g);
              return (
                <div key={g} style={{ display:"flex", alignItems:"center", gap:10, background:done?"#0a1a0a":"#0a0a1e", border:`1px solid ${done?"#22c55e33":"#2a2a5533"}`, borderRadius:12, padding:"10px 14px", marginBottom:6 }}>
                  <div style={{ fontSize:22 }}>{done?"✅":info.emoji}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:800, fontSize:14, color:done?"#22c55e":"#e0e0ff" }}>{info.name}</div>
                    <div style={{ fontSize:10, color:"#5555aa" }}>Faça exercícios deste grupo</div>
                  </div>
                  <div style={{ fontSize:11, fontWeight:700, color:done?"#22c55e":info.color }}>{done?"Feito!":"Pendente"}</div>
                </div>
              );
            })}
          </div>

          {/* Missões Especiais Preview */}
          <div style={{ ...S.card, marginBottom:14 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
              <div style={S.label}>🎯 MISSÕES ESPECIAIS</div>
              <div style={{ fontSize:12, color:"#8888cc", fontWeight:700 }}>{questsDone}/{questsTotal}</div>
            </div>
            {session.dailyMissions.slice(0,3).map(m=>{
              const done = session.questCompleted.includes(m.id);
              const prog = session.questProgress[m.id]||0;
              const max  = typeof m.target==="number"?m.target:(m.target?.count||1);
              const pct  = done?100:Math.min(100,(prog/max)*100);
              return (
                <div key={m.id} style={{ background:done?"#0a1a0a":RARITY_BG[m.rarity], border:`1px solid ${done?"#22c55e33":RARITY_COLORS[m.rarity]+"33"}`, borderRadius:12, padding:"10px 14px", marginBottom:6 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
                    <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                      <span style={{ fontSize:18 }}>{done?"✅":m.icon}</span>
                      <div>
                        <div style={{ fontSize:13, fontWeight:800, color:done?"#22c55e":"#e0e0ff" }}>{m.title}</div>
                        <div style={{ fontSize:10, color:"#5555aa" }}>{m.desc}</div>
                      </div>
                    </div>
                    <div style={{ textAlign:"right" }}>
                      <div style={{ fontSize:10, color:RARITY_COLORS[m.rarity], fontWeight:700 }}>{m.rarity}</div>
                      <div style={{ fontSize:10, color:"#ffd700" }}>+{m.reward.xp}XP</div>
                    </div>
                  </div>
                  <div style={{ background:"#0d0d22", borderRadius:4, height:5, overflow:"hidden" }}>
                    <div style={{ width:`${pct}%`, height:"100%", background:done?"#22c55e":RARITY_COLORS[m.rarity], transition:"width 0.5s ease" }} />
                  </div>
                </div>
              );
            })}
            <button onClick={()=>setScreen("missions")} style={{ ...S.btn("#333355",true), marginTop:6 }}>Ver todas as missões →</button>
          </div>

          <button style={S.btn("#6644ff")} onClick={startBattle}>⚔️ BATALHAR AGORA</button>
          <div style={{ fontSize:11, color:"#333355", textAlign:"center", marginTop:8 }}>
            {player.totalWorkouts} exercícios • {player.wins} vitórias
          </div>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════
  // MISSIONS SCREEN
  // ════════════════════════════════════════════════════════════
  if (screen==="missions") {
    const dayNames = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
    const today    = new Date().getDay();

    return (
      <div style={S.app}>
        <style>{CSS}</style>
        <div style={{ width:"100%", maxWidth:460, padding:"24px 16px 0" }}>

          <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:20 }}>
            <button onClick={()=>setScreen("home")} style={{ background:"none", border:"1px solid #33335544", borderRadius:10, color:"#8888cc", padding:"8px 12px", cursor:"pointer", fontSize:13, fontFamily:"inherit" }}>←</button>
            <div style={{ fontSize:20, fontWeight:900, color:"#c8b8ff" }}>🎯 Missões</div>
          </div>

          {/* Missões Especiais */}
          <div style={{ ...S.label, marginBottom:10 }}>⭐ MISSÕES DO DIA</div>
          {session.dailyMissions.map(m=>{
            const done = session.questCompleted.includes(m.id);
            const prog = session.questProgress[m.id]||0;
            const max  = typeof m.target==="number"?m.target:(m.target?.count||1);
            const pct  = done?100:Math.min(100,(prog/max)*100);
            return (
              <div key={m.id} style={{ ...S.card, marginBottom:10, border:`2px solid ${done?"#22c55e44":RARITY_COLORS[m.rarity]+"33"}`, animation:"slideIn 0.3s ease" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                  <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                    <div style={{ fontSize:32, filter:`drop-shadow(0 0 8px ${RARITY_COLORS[m.rarity]})` }}>{done?"✅":m.icon}</div>
                    <div>
                      <div style={{ fontSize:16, fontWeight:900, color:done?"#22c55e":"#e0e0ff" }}>{m.title}</div>
                      <div style={{ fontSize:11, color:"#5555aa", marginTop:2 }}>{m.desc}</div>
                    </div>
                  </div>
                  <div style={{ background:RARITY_BG[m.rarity], border:`1px solid ${RARITY_COLORS[m.rarity]}44`, borderRadius:8, padding:"3px 8px", textAlign:"center" }}>
                    <div style={{ fontSize:10, color:RARITY_COLORS[m.rarity], fontWeight:800 }}>{m.rarity.toUpperCase()}</div>
                  </div>
                </div>

                {/* Barra de progresso */}
                <div style={{ background:"#0d0d22", borderRadius:6, height:8, overflow:"hidden", marginBottom:6 }}>
                  <div style={{ width:`${pct}%`, height:"100%", background:done?"#22c55e":RARITY_COLORS[m.rarity], transition:"width 0.5s ease", boxShadow:`0 0 6px ${RARITY_COLORS[m.rarity]}88` }} />
                </div>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:11 }}>
                  <span style={{ color:"#5555aa" }}>{done?"Concluída! 🎉":`Progresso: ${prog}/${max}`}</span>
                  <span style={{ color:"#ffd700", fontWeight:700 }}>+{m.reward.xp}XP +{m.reward.gold}💰</span>
                </div>
              </div>
            );
          })}

          {/* Plano semanal */}
          <div style={{ ...S.label, margin:"18px 0 10px" }}>📅 PLANO SEMANAL</div>
          <div style={{ ...S.card, marginBottom:12 }}>
            <div style={{ fontSize:12, color:"#5555aa", marginBottom:12 }}>
              Grupos musculares alternam para evitar lesões e equilibrar o treino.
            </div>
            {WEEKLY_PLAN.map((groups,i)=>{
              const isToday = i===today;
              return (
                <div key={i} style={{
                  display:"flex", alignItems:"center", gap:10,
                  background:isToday?"#0f0f30":"#0a0a1a",
                  border:`1px solid ${isToday?"#6644ff66":"#1a1a3333"}`,
                  borderRadius:12, padding:"10px 14px", marginBottom:6,
                  boxShadow:isToday?"0 0 12px #6644ff22":"none"
                }}>
                  <div style={{ width:36, textAlign:"center" }}>
                    <div style={{ fontSize:12, fontWeight:900, color:isToday?"#c8b8ff":"#5555aa" }}>{dayNames[i]}</div>
                    {isToday && <div style={{ fontSize:9, color:"#6644ff", fontWeight:800 }}>HOJE</div>}
                  </div>
                  <div style={{ display:"flex", gap:6, flexWrap:"wrap", flex:1 }}>
                    {groups.map(g=>{
                      const info=MUSCLE_GROUPS[g];
                      const done=isToday&&session.missionsCompleted.includes(g);
                      return (
                        <div key={g} style={{ background:done?"#0a2010":RARITY_BG.comum, border:`1px solid ${done?"#22c55e44":info.color+"33"}`, borderRadius:8, padding:"3px 8px", fontSize:11, color:done?"#22c55e":info.color, fontWeight:700 }}>
                          {info.emoji} {info.name}{done?" ✅":""}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          <button style={S.btn("#6644ff")} onClick={startBattle}>⚔️ Ir para batalha</button>
          <button style={{ ...S.btn("#111130"), marginTop:4 }} onClick={()=>setScreen("home")}>🏠 Menu</button>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════
  // BATTLE
  // ════════════════════════════════════════════════════════════
  if (screen==="battle" && enemy) {
    const todayGroups = getTodayGroups();
    return (
      <div style={S.app}>
        <style>{CSS}</style>
        <div style={{ width:"100%", maxWidth:460, padding:"16px 14px" }}>

          {/* Notificação de missão */}
          {newQuestMsg && (
            <div style={{ background:"#1a1400", border:"1px solid #ffd70066", borderRadius:14, padding:"10px 16px", marginBottom:10, fontSize:13, color:"#ffd700", fontWeight:700, animation:"slideIn 0.3s ease", textAlign:"center" }}>
              {newQuestMsg}
            </div>
          )}
          {warningMsg && (
            <div style={{ background:"#2a0a0a", border:"1px solid #ff444466", borderRadius:14, padding:"10px 16px", marginBottom:10, fontSize:13, color:"#ff8888", fontWeight:700, animation:"slideIn 0.3s ease" }}>
              ⚠️ {warningMsg}
            </div>
          )}

          {/* Enemy */}
          <div style={{ ...S.card, marginBottom:10, position:"relative", overflow:"hidden" }}>
            <FloatingText texts={floats} />
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
              <div>
                <div style={{ fontSize:11, color:"#ff6666", fontWeight:700 }}>⚠️ INIMIGO — Nv.{ENEMIES[enemyIdx]?.level}</div>
                <div style={{ fontSize:19, fontWeight:900 }}>{enemy.name}</div>
              </div>
              <div style={{ fontSize:56, animation:"bounce 2.2s ease-in-out infinite", filter:"drop-shadow(0 0 12px #ff444455)" }}>{enemy.emoji}</div>
            </div>
            <HealthBar current={enemy.hp} max={enemy.maxHp} color="#ef4444" />
            <div style={{ textAlign:"right", fontSize:11, color:"#ff8888", marginTop:3 }}>{enemy.hp}/{enemy.maxHp}</div>
          </div>

          {/* Player */}
          <div style={{ ...S.card, marginBottom:10, animation:shake?"shake 0.5s":"none" }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
              <div style={{ fontSize:11, color:"#6699ff", fontWeight:700 }}>🧙 Nv.{player.level} {defending&&"🛡️"}</div>
              <div style={{ fontSize:11, color:"#9988ff" }}>⚡{player.xp}/{player.xpNeeded}XP</div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
              <div>
                <div style={S.label}>❤️ HP</div>
                <HealthBar current={player.hp} max={player.maxHp} color="#22c55e" />
                <div style={{ fontSize:10, color:"#88cc88", marginTop:2 }}>{player.hp}/{player.maxHp}</div>
              </div>
              <EnergyBar current={session.energy} max={session.maxEnergy} />
            </div>
          </div>

          {/* Log */}
          {log.length>0 && (
            <div style={{ background:"#060612", border:"1px solid #1a1a3344", borderRadius:12, padding:"8px 12px", marginBottom:10 }}>
              {log.slice(0,3).map(l=><div key={l.id} style={{ color:l.color, fontSize:12, marginBottom:1 }}>{l.msg}</div>)}
            </div>
          )}

          {/* Exercícios */}
          <div style={{ ...S.label, marginBottom:8 }}>⚔️ ESCOLHA SEU ATAQUE</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:10 }}>
            {EXERCISES.map(ex=>{
              const {ok} = canDoExercise(ex);
              const g    = MUSCLE_GROUPS[ex.group];
              const isMission = todayGroups.includes(ex.group);
              const isQuestEx = session.dailyMissions.some(m=>!session.questCompleted.includes(m.id)&&(m.type==="group"&&m.target===ex.group||m.type==="groupCount"&&m.target.group===ex.group||m.type==="exCount"&&m.target.id===ex.id));
              const cd   = session.groupCooldowns[ex.group]||0;
              const typeColors = {attack:"#6644ff",special:"#ff4466",defend:"#22c55e",magic:"#00aaff"};
              const c    = ok ? typeColors[ex.type] : "#333355";
              const repsLabel = ex.type==="defend"?`${getDurationForLevel(ex.id,player.level)}s`:`×${getRepsForLevel(ex.id,player.level)}`;
              return (
                <button key={ex.id} onClick={()=>pickExercise(ex)}
                  style={{ ...S.btn(c), opacity:ok?1:0.45, display:"flex", flexDirection:"column", alignItems:"flex-start", padding:"12px 13px", gap:2, position:"relative" }}>
                  {isMission&&ok&&<div style={{ position:"absolute", top:5, right:8, fontSize:9, color:"#ffd700", fontWeight:900 }}>★ HOJE</div>}
                  {isQuestEx&&ok&&<div style={{ position:"absolute", top:ok&&isMission?16:5, right:8, fontSize:9, color:"#00ffcc", fontWeight:900 }}>🎯</div>}
                  <span style={{ fontSize:20 }}>{ex.emoji}</span>
                  <span style={{ fontSize:13, fontWeight:900 }}>{ex.name}</span>
                  <span style={{ fontSize:10, color:g.color }}>{g.emoji} {g.name}</span>
                  <div style={{ display:"flex", gap:5 }}>
                    <span style={{ fontSize:10, opacity:0.8 }}>{repsLabel}</span>
                    <span style={{ fontSize:10, color:"#ffcc88" }}>⚡{energyCostOf(ex)}</span>
                    {ex.damage>0&&<span style={{ fontSize:10, color:"#ff9988" }}>⚔️{ex.damage}</span>}
                  </div>
                  {!ok&&cd>0&&<span style={{ fontSize:9, color:"#ff6644" }}>😴 {cd} ex.</span>}
                  {!ok&&cd===0&&<span style={{ fontSize:9, color:"#ff6644" }}>⚡ sem energia</span>}
                </button>
              );
            })}
          </div>

          {Object.keys(session.groupCooldowns).length>0&&(
            <div style={{ background:"#0a0a1a", borderRadius:12, padding:"8px 14px", marginBottom:8, border:"1px solid #ff666622" }}>
              <div style={{ fontSize:11, color:"#ff8866", fontWeight:700, marginBottom:4 }}>😴 EM DESCANSO:</div>
              {Object.entries(session.groupCooldowns).map(([g,v])=>(
                <div key={g} style={{ fontSize:11, color:"#aa8866" }}>{MUSCLE_GROUPS[g]?.emoji} {MUSCLE_GROUPS[g]?.name} — {v} ex. restante(s)</div>
              ))}
            </div>
          )}

          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
            <button onClick={()=>setScreen("missions")} style={{ ...S.btn("#222244",true) }}>🎯 Missões</button>
            <button onClick={()=>setScreen("home")} style={{ ...S.btn("#111130",true) }}>🏠 Menu</button>
          </div>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════
  // EXERCISE
  // ════════════════════════════════════════════════════════════
  if (screen==="exercise" && activeExercise) {
    const isTimer  = activeExercise.type==="defend";
    const required = isTimer ? getDurationForLevel(activeExercise.id,player.level) : getRepsForLevel(activeExercise.id,player.level);
    const progress = Math.min(1,(isTimer?timer:reps)/required);
    const typeColors={attack:"#6644ff",special:"#ff4466",defend:"#22c55e",magic:"#00aaff"};
    const c  = typeColors[activeExercise.type];
    const g  = MUSCLE_GROUPS[activeExercise.group];
    const circ = 2*Math.PI*68;

    return (
      <div style={S.app}>
        <style>{CSS}</style>
        <div style={{ width:"100%", maxWidth:460, padding:"24px 16px" }}>
          <div style={{ ...S.card, textAlign:"center" }}>
            <div style={{ fontSize:11, color:c, fontWeight:800, letterSpacing:2, marginBottom:4 }}>EXERCÍCIO ATIVO</div>
            <div style={{ fontSize:11, color:g.color, marginBottom:10 }}>{g.emoji} {g.name} • Intensidade {activeExercise.intensity}/3 • ⚡{energyCostOf(activeExercise)}</div>
            <div style={{ fontSize:68, marginBottom:4, animation:"pulse 1.2s ease-in-out infinite", filter:`drop-shadow(0 0 18px ${c})` }}>{activeExercise.emoji}</div>
            <div style={{ fontSize:22, fontWeight:900, marginBottom:8 }}>{activeExercise.name}</div>

            <button onClick={()=>setShowTip(!showTip)} style={{ background:"none", border:`1px solid ${c}44`, borderRadius:20, color:c, fontSize:11, padding:"4px 12px", cursor:"pointer", marginBottom:14, fontFamily:"inherit" }}>
              💡 {showTip?"Ocultar dica":"Ver dica de forma"}
            </button>
            {showTip&&(
              <div style={{ background:"#0a0a22", border:`1px solid ${c}33`, borderRadius:12, padding:"10px 14px", marginBottom:12, fontSize:13, color:"#aaaacc", animation:"slideIn 0.3s ease" }}>
                {activeExercise.tip}
              </div>
            )}

            <div style={{ position:"relative", width:160, height:160, margin:"0 auto 18px" }}>
              <svg width="160" height="160" style={{ position:"absolute", inset:0, transform:"rotate(-90deg)" }}>
                <circle cx="80" cy="80" r="68" fill="none" stroke="#0d0d22" strokeWidth="14"/>
                <circle cx="80" cy="80" r="68" fill="none" stroke={c} strokeWidth="14"
                  strokeDasharray={circ} strokeDashoffset={circ*(1-progress)}
                  strokeLinecap="round"
                  style={{ transition:"stroke-dashoffset 0.35s ease", filter:`drop-shadow(0 0 8px ${c})` }}
                />
              </svg>
              <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
                <div style={{ fontSize:46, fontWeight:900, color:c }}>{isTimer?timer:reps}</div>
                <div style={{ fontSize:11, color:"#6666aa" }}>/ {required}{isTimer?"s":" reps"}</div>
              </div>
            </div>

            <div style={{ background:"#0a0a20", borderRadius:12, padding:"10px 14px", marginBottom:16, border:`1px solid ${c}22` }}>
              {isTimer
                ?<><div style={{ fontWeight:800, marginBottom:3 }}>🛡️ Segure a prancha!</div><div style={{ fontSize:12, color:"#7777aa" }}>{timer<required?`Aguente mais ${required-timer}s...`:"Quase lá! 🎉"}</div></>
                :<><div style={{ fontWeight:800, marginBottom:5 }}>Toque a cada repetição</div><div style={{ display:"flex", justifyContent:"center", gap:16, fontSize:11, color:"#7777aa" }}><span>✅ Boa forma</span><span>🌬️ Respire</span><span>⚡ Ritmo</span></div></>
              }
            </div>

            {!isTimer
              ?<button onClick={addRep} style={{ ...S.btn(c), fontSize:20, padding:"18px 24px", animation:"pulse 1.8s ease-in-out infinite" }}>💪 +1 REP</button>
              :<div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
                <button onClick={()=>{clearInterval(timerRef.current);setIsTimerRunning(false);}} style={S.btn("#ff5544")}>⏸ Pausar</button>
                <button onClick={()=>{if(!isTimerRunning){setIsTimerRunning(true);timerRef.current=setInterval(()=>setTimer(t=>t+1),1000);}}} style={S.btn("#22c55e")}>▶ Continuar</button>
              </div>
            }
            <button onClick={()=>{clearInterval(timerRef.current);setSession(s=>({...s,sequenceCount:0}));setScreen("battle");}} style={{ background:"none",border:"none",color:"#444466",padding:"10px",cursor:"pointer",marginTop:6,fontSize:12,fontFamily:"inherit" }}>
              ✖ Cancelar
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════
  // VICTORY
  // ════════════════════════════════════════════════════════════
  if (screen==="victory") {
    const allDone = getTodayGroups().every(g=>session.missionsCompleted.includes(g));
    const qDone   = session.questCompleted.length;
    return (
      <div style={S.app}>
        <style>{CSS}</style>
        <div style={{ ...S.card, margin:"50px 16px 0", textAlign:"center" }}>
          <div style={{ fontSize:70, display:"inline-block", animation:"spin 3s linear infinite" }}>🏆</div>
          <div style={{ fontSize:24, fontWeight:900, color:"#ffd700", margin:"10px 0 4px" }}>VITÓRIA!</div>
          <div style={{ color:"#8888cc", fontSize:13, marginBottom:16 }}>{ENEMIES[(enemyIdx-1+ENEMIES.length)%ENEMIES.length]?.name} derrotado!</div>
          {allDone&&<div style={{ background:"#1a1400",border:"1px solid #ffd70055",borderRadius:12,padding:"10px",marginBottom:12 }}><div style={{ color:"#ffd700",fontWeight:900 }}>⭐ PLANO DO DIA COMPLETO!</div></div>}
          {qDone>0&&<div style={{ background:"#001a10",border:"1px solid #22c55e44",borderRadius:12,padding:"10px",marginBottom:12 }}><div style={{ color:"#22c55e",fontWeight:900 }}>🎯 {qDone} missão(ões) especial(is) completa(s)!</div></div>}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:16 }}>
            {[["🏆","Nível",player.level],["⚡","XP",`${player.xp}/${player.xpNeeded}`],["💰","Ouro",player.gold],["🔥","Streak",`${player.streak}d`]].map(([i,l,v])=>(
              <div key={l} style={{ background:"#0a0a18",borderRadius:12,padding:10,border:"1px solid #ffd70022" }}>
                <div style={{ fontSize:18 }}>{i}</div>
                <div style={{ fontSize:10,color:"#555577" }}>{l}</div>
                <div style={{ fontWeight:900,color:"#ffd700",fontSize:15 }}>{v}</div>
              </div>
            ))}
          </div>
          {session.energy>10
            ?<button style={S.btn("#6644ff")} onClick={startBattle}>⚔️ Próxima batalha</button>
            :<div style={{ background:"#1a0a0a",border:"1px solid #ff444433",borderRadius:12,padding:12,marginBottom:8 }}><div style={{ color:"#ff8866",fontWeight:800 }}>⚡ Energia esgotada por hoje!</div><div style={{ fontSize:11,color:"#884444",marginTop:4 }}>Ótimo treino! Descanse e volte amanhã.</div></div>
          }
          <button style={{ ...S.btn("#222244"),marginTop:4 }} onClick={()=>setScreen("home")}>🏠 Menu</button>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════
  // LEVEL UP
  // ════════════════════════════════════════════════════════════
  if (screen==="levelup") return (
    <div style={S.app}>
      <style>{CSS}</style>
      <div style={{ ...S.card, margin:"50px 16px 0", textAlign:"center", border:"2px solid #ffd700" }}>
        <div style={{ fontSize:70 }}>⭐</div>
        <div style={{ fontSize:26,fontWeight:900,color:"#ffd700" }}>LEVEL UP!</div>
        <div style={{ fontSize:50,fontWeight:900,color:"#c8b8ff",margin:"10px 0" }}>Nível {player.level}</div>
        <div style={{ color:"#8888cc",fontSize:13,marginBottom:6 }}>HP máximo +15 • Reps aumentam!</div>
        <button style={S.btn("#ffd700")} onClick={()=>{if(enemy&&enemy.hp>0)setScreen("battle");else startBattle();}}>⚔️ Continuar!</button>
      </div>
    </div>
  );

  // ════════════════════════════════════════════════════════════
  // DEFEAT
  // ════════════════════════════════════════════════════════════
  if (screen==="defeat") return (
    <div style={S.app}>
      <style>{CSS}</style>
      <div style={{ ...S.card, margin:"50px 16px 0", textAlign:"center", border:"1px solid #ff444433" }}>
        <div style={{ fontSize:70 }}>💀</div>
        <div style={{ fontSize:24,fontWeight:900,color:"#ff4444" }}>DERROTA...</div>
        <div style={{ color:"#8888aa",margin:"10px 0 18px",fontSize:13 }}>Descanse, guerreiro. Recupere forças para a próxima!</div>
        {session.energy>10
          ?<button style={S.btn("#6644ff")} onClick={()=>{setPlayer(p=>({...p,hp:p.maxHp}));startBattle();}}>🔄 Tentar novamente</button>
          :<div style={{ color:"#ff8844",fontWeight:700,marginBottom:12 }}>⚡ Energia esgotada — volte amanhã!</div>
        }
        <button style={{ ...S.btn("#222244"),marginTop:4 }} onClick={()=>{setPlayer(p=>({...p,hp:p.maxHp}));setScreen("home");}}>🏠 Menu</button>
      </div>
    </div>
  );

  return null;
}
