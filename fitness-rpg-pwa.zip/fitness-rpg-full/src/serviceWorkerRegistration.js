// ═══════════════════════════════════════════════════════════
// Fitness RPG — Service Worker Registration
// ═══════════════════════════════════════════════════════════

const isLocalhost = Boolean(
  window.location.hostname === 'localhost' ||
  window.location.hostname === '[::1]' ||
  window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/)
);

export function register(config = {}) {
  if (!('serviceWorker' in navigator)) {
    console.warn('[PWA] Service Workers não suportados neste navegador.');
    return;
  }

  window.addEventListener('load', () => {
    const swUrl = `${process.env.PUBLIC_URL}/service-worker.js`;

    if (isLocalhost) {
      checkValidServiceWorker(swUrl, config);
      navigator.serviceWorker.ready.then(() => {
        console.log('[PWA] App rodando com Service Worker em localhost.');
      });
    } else {
      registerValidSW(swUrl, config);
    }
  });
}

async function registerValidSW(swUrl, config) {
  try {
    const registration = await navigator.serviceWorker.register(swUrl);

    registration.onupdatefound = () => {
      const installing = registration.installing;
      if (!installing) return;

      installing.onstatechange = () => {
        if (installing.state !== 'installed') return;

        if (navigator.serviceWorker.controller) {
          // Nova versão disponível
          console.log('[PWA] Nova versão disponível! Atualize para usar.');
          if (config.onUpdate) config.onUpdate(registration);
        } else {
          // Conteúdo cacheado para uso offline
          console.log('[PWA] Conteúdo cacheado para uso offline.');
          if (config.onSuccess) config.onSuccess(registration);
        }
      };
    };
  } catch (error) {
    console.error('[PWA] Erro ao registrar Service Worker:', error);
  }
}

async function checkValidServiceWorker(swUrl, config) {
  try {
    const response = await fetch(swUrl, { headers: { 'Service-Worker': 'script' } });
    const contentType = response.headers.get('content-type');

    if (response.status === 404 || (contentType && !contentType.includes('javascript'))) {
      // SW não encontrado — desregistra e recarrega
      const registration = await navigator.serviceWorker.ready;
      await registration.unregister();
      window.location.reload();
    } else {
      registerValidSW(swUrl, config);
    }
  } catch {
    console.log('[PWA] Sem conexão. App rodando em modo offline.');
  }
}

export function unregister() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready
      .then((registration) => registration.unregister())
      .catch((error) => console.error(error.message));
  }
}

// ── Solicitar permissão de notificações ───────────────────
export async function requestNotificationPermission() {
  if (!('Notification' in window)) return 'unsupported';
  if (Notification.permission === 'granted') return 'granted';
  if (Notification.permission === 'denied') return 'denied';
  const permission = await Notification.requestPermission();
  return permission;
}

// ── Detectar se já está instalado como PWA ────────────────
export function isInstalledPWA() {
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    window.navigator.standalone === true
  );
}
