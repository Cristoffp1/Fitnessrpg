import { useState, useEffect, useRef, useCallback } from "react";
import usePWA from "./usePWA";

// ═══════════════════════════════════════════════════════════
// DATA
// ═══════════════════════════════════════════════════════════

const XP_PER_LEVEL = (lvl) => Math.floor(100 * Math.pow(lvl, 1.5));

const DAILY_MISSIONS = [
  { id:"d1",  title:"Guerreiro das Flexões",   desc:"Complete 20 flexões",          icon:"💪", xp:80,  target:20, unit:"flexões",     diff:"Fácil",  category:"força"   },
  { id:"d2",  title:"Pernas de Aço",           desc:"Complete 30 agachamentos",     icon:"🦵", xp:80,  target:30, unit:"agacham.",   diff:"Fácil",  category:"força"   },
  { id:"d3",  title:"Núcleo de Ferro",         desc:"Prancha por 60 segundos",      icon:"🔥", xp:100, target:60, unit:"segundos",    diff:"Médio",  category:"core"    },
  { id:"d4",  title:"Sprint do Lar",           desc:"Polichinelos por 2 minutos",   icon:"⚡", xp:90,  target:120,unit:"segundos",    diff:"Médio",  category:"cardio"  },
  { id:"d5",  title:"Bloco de Concreto",       desc:"Complete 15 burpees",          icon:"🏋️", xp:120, target:15, unit:"burpees",     diff:"Difícil",category:"fullbody"},
  { id:"d6",  title:"Mestre do Core",          desc:"50 abdominais",                icon:"🎯", xp:90,  target:50, unit:"abdominais",  diff:"Médio",  category:"core"    },
  { id:"d7",  title:"Escalador",               desc:"Mountain climbers por 45s",    icon:"🧗", xp:110, target:45, unit:"segundos",    diff:"Difícil",category:"cardio"  },
  { id:"d8",  title:"Afundo Profundo",         desc:"20 afundos por perna",         icon:"🦶", xp:85,  target:40, unit:"afundos",     diff:"Médio",  category:"força"   },
];

const WEEKLY_MISSIONS = [
  { id:"w1", title:"Semana do Guerreiro",    desc:"Treine 5 dias esta semana",         icon:"🗓️", xp:500,  target:5,  unit:"dias",          diff:"Épico"   },
  { id:"w2", title:"Centurião",              desc:"Complete 100 flexões esta semana",   icon:"💯", xp:400,  target:100,unit:"flexões",        diff:"Difícil" },
  { id:"w3", title:"Maratona em Casa",       desc:"Acumule 30 min de cardio na semana", icon:"🏃", xp:450,  target:30, unit:"minutos",        diff:"Difícil" },
  { id:"w4", title:"Mestre da Consistência", desc:"Complete 3 missões por dia, 3 dias", icon:"⭐", xp:600,  target:9,  unit:"missões",        diff:"Épico"   },
];

const SPECIAL_MISSIONS = [
  { id:"s1", title:"Despertar do Herói",   desc:"Complete sua primeira missão",          icon:"🌅", xp:50,   target:1,  unit:"missão",      diff:"Iniciante", once:true },
  { id:"s2", title:"Madrugador",           desc:"Complete uma missão antes das 9h",      icon:"🌄", xp:150,  target:1,  unit:"missão",      diff:"Especial",  once:true },
  { id:"s3", title:"Trindade",             desc:"Complete 3 categorias diferentes hoje", icon:"🔱", xp:200,  target:3,  unit:"categorias",  diff:"Especial"   },
  { id:"s4", title:"Imparável",            desc:"7 dias seguidos treinando",             icon:"🔥", xp:700,  target:7,  unit:"dias",        diff:"Lendário"   },
  { id:"s5", title:"Centurião Total",      desc:"100 missões concluídas",                icon:"👑", xp:1000, target:100,unit:"missões",     diff:"Lendário"   },
];

const ACHIEVEMENTS = [
  { id:"a1",  title:"Primeira Missão",        desc:"Complete sua primeira missão",           icon:"🌟", condition:(s)=>s.totalMissions>=1    },
  { id:"a2",  title:"Em Forma",               desc:"Complete 10 missões",                    icon:"💪", condition:(s)=>s.totalMissions>=10   },
  { id:"a3",  title:"Dedicado",               desc:"Complete 25 missões",                    icon:"🎯", condition:(s)=>s.totalMissions>=25   },
  { id:"a4",  title:"Guerreiro",              desc:"Complete 50 missões",                    icon:"⚔️", condition:(s)=>s.totalMissions>=50   },
  { id:"a5",  title:"100 Missões",            desc:"Complete 100 missões",                   icon:"💯", condition:(s)=>s.totalMissions>=100  },
  { id:"a6",  title:"Sequência de 3 Dias",    desc:"Treine 3 dias seguidos",                 icon:"🔥", condition:(s)=>s.streak>=3           },
  { id:"a7",  title:"7 Dias Consecutivos",    desc:"Treine 7 dias seguidos",                 icon:"🗓️", condition:(s)=>s.streak>=7           },
  { id:"a8",  title:"Mês Perfeito",           desc:"Treine 30 dias seguidos",                icon:"🏆", condition:(s)=>s.streak>=30          },
  { id:"a9",  title:"Nível 5",               desc:"Atinja o nível 5",                       icon:"⭐", condition:(s)=>s.level>=5            },
  { id:"a10", title:"Nível 10",              desc:"Atinja o nível 10",                      icon:"🌠", condition:(s)=>s.level>=10           },
  { id:"a11", title:"Nível 25",              desc:"Atinja o nível 25",                      icon:"💎", condition:(s)=>s.level>=25           },
  { id:"a12", title:"Nível 50",              desc:"Atinja o nível 50",                      icon:"👑", condition:(s)=>s.level>=50           },
  { id:"a13", title:"Mestre das Flexões",     desc:"Complete 200 flexões no total",          icon:"💥", condition:(s)=>s.totalFlexoes>=200   },
  { id:"a14", title:"Pernas de Titânio",      desc:"Complete 300 agachamentos no total",     icon:"🦾", condition:(s)=>s.totalAgacham>=300   },
  { id:"a15", title:"Guardião do Core",       desc:"Acumule 10 minutos de prancha",          icon:"🛡️", condition:(s)=>s.totalPrancha>=600   },
  { id:"a16", title:"Guerreiro da Disciplina",desc:"Complete 5 missões em um único dia",     icon:"🧠", condition:(s)=>s.maxDayMissions>=5   },
  { id:"a17", title:"Invicto",               desc:"Complete uma semana sem falhar",          icon:"⚡", condition:(s)=>s.perfectWeeks>=1     },
  { id:"a18", title:"Lendário",              desc:"Atinja o nível 50 com 200 missões",      icon:"🌈", condition:(s)=>s.level>=50&&s.totalMissions>=200 },
];

const DIFF_COLORS = {
  "Iniciante":"#22c55e","Fácil":"#22c55e","Médio":"#f59e0b",
  "Difícil":"#ef4444","Especial":"#a855f7","Épico":"#f97316","Lendário":"#ec4899"
};

const CAT_COLORS = { força:"#ef4444", core:"#f59e0b", cardio:"#00aaff", fullbody:"#a855f7" };

// Ranking simulado
const RANKING_DATA = {
  regional: [
    { name:"VitóriaFit",   level:34, xp:28400, missions:187, avatar:"🦁" },
    { name:"LucasPower",   level:29, xp:21800, missions:142, avatar:"⚡" },
    { name:"AnaWarrior",   level:27, xp:19200, missions:131, avatar:"🔥" },
    { name:"BrunoIron",    level:22, xp:14100, missions:98,  avatar:"💪" },
    { name:"CamilaSteel",  level:18, xp:10500, missions:76,  avatar:"🛡️" },
    { name:"DiegoBlaze",   level:15, xp:8200,  missions:58,  avatar:"⚔️" },
    { name:"EduardoFlex",  level:12, xp:5900,  missions:43,  avatar:"🏋️" },
    { name:"FernandaZen",  level:9,  xp:3400,  missions:27,  avatar:"🧘" },
  ],
  nacional: [
    { name:"KingFitBR",    level:67, xp:89200, missions:412, avatar:"👑" },
    { name:"TitanHome",    level:58, xp:71400, missions:349, avatar:"⚡" },
    { name:"EliteWarrior", level:51, xp:60100, missions:304, avatar:"🔱" },
    { name:"PhoenixFit",   level:45, xp:48700, missions:261, avatar:"🔥" },
    { name:"IronMindBR",   level:40, xp:39300, missions:218, avatar:"🦾" },
    { name:"VitóriaFit",   level:34, xp:28400, missions:187, avatar:"🦁" },
    { name:"LucasPower",   level:29, xp:21800, missions:142, avatar:"⚡" },
    { name:"AnaWarrior",   level:27, xp:19200, missions:131, avatar:"🔥" },
  ],
  mundial: [
    { name:"WorldBeast",   level:120,xp:312000,missions:987, avatar:"🌍" },
    { name:"GlobeFit",     level:98, xp:210000,missions:801, avatar:"🌎" },
    { name:"PlanetWarrior",level:89, xp:178000,missions:721, avatar:"🏆" },
    { name:"UltraHero",    level:77, xp:140000,missions:601, avatar:"👑" },
    { name:"MegaFit",      level:70, xp:118000,missions:534, avatar:"💎" },
    { name:"KingFitBR",    level:67, xp:89200, missions:412, avatar:"⚡" },
    { name:"TitanHome",    level:58, xp:71400, missions:349, avatar:"🔥" },
    { name:"EliteWarrior", level:51, xp:60100, missions:304, avatar:"⭐" },
  ],
};

// ═══════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════

function getTotalXpForLevel(lvl) {
  let total = 0;
  for (let i=1;i<lvl;i++) total += XP_PER_LEVEL(i);
  return total;
}

function getLevelFromXp(xp) {
  let lvl=1, acc=0;
  while (acc+XP_PER_LEVEL(lvl)<=xp) { acc+=XP_PER_LEVEL(lvl); lvl++; }
  return { level:lvl, xpInLevel:xp-acc, xpNeeded:XP_PER_LEVEL(lvl) };
}

function todayKey() {
  const d=new Date(); return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

function weekKey() {
  const d=new Date();
  const start = new Date(d); start.setDate(d.getDate()-d.getDay());
  return `${start.getFullYear()}-${start.getMonth()}-${start.getDate()}`;
}

// ═══════════════════════════════════════════════════════════
// COMPONENTS
// ═══════════════════════════════════════════════════════════

function XPRing({ xpInLevel, xpNeeded, level, size=96 }) {
  const r = size/2-8;
  const circ = 2*Math.PI*r;
  const pct = xpInLevel/xpNeeded;
  return (
    <div style={{ position:"relative", width:size, height:size }}>
      <svg width={size} height={size} style={{ position:"absolute", inset:0, transform:"rotate(-90deg)" }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#1a1b3a" strokeWidth="8"/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="url(#xpGrad)" strokeWidth="8"
          strokeDasharray={circ} strokeDashoffset={circ*(1-pct)}
          strokeLinecap="round" style={{ transition:"stroke-dashoffset 0.6s ease", filter:"drop-shadow(0 0 6px #7C3AED)" }}/>
        <defs>
          <linearGradient id="xpGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#7C3AED"/>
            <stop offset="100%" stopColor="#A855F7"/>
          </linearGradient>
        </defs>
      </svg>
      <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
        <div style={{ fontSize:22, fontWeight:900, color:"#F59E0B", lineHeight:1 }}>{level}</div>
        <div style={{ fontSize:9, color:"#6666aa", fontWeight:700, letterSpacing:1 }}>NÍVEL</div>
      </div>
    </div>
  );
}

function ProgressBar({ value, max, color="#7C3AED", height=8 }) {
  return (
    <div style={{ background:"#0d0d22", borderRadius:99, height, overflow:"hidden", border:"1px solid #2a2a4a" }}>
      <div style={{ width:`${Math.min(100,(value/max)*100)}%`, height:"100%", background:`linear-gradient(90deg,${color}cc,${color})`, borderRadius:99, transition:"width 0.5s ease", boxShadow:`0 0 6px ${color}66` }}/>
    </div>
  );
}

function Badge({ diff }) {
  const c = DIFF_COLORS[diff]||"#888";
  return (
    <span style={{ background:`${c}22`, border:`1px solid ${c}55`, borderRadius:20, padding:"2px 8px", fontSize:10, color:c, fontWeight:800 }}>{diff}</span>
  );
}

function Particles({ active }) {
  const particles = Array.from({length:16},(_,i)=>i);
  if (!active) return null;
  return (
    <div style={{ position:"fixed", inset:0, pointerEvents:"none", zIndex:999 }}>
      {particles.map(i=>(
        <div key={i} style={{
          position:"absolute",
          left:`${Math.random()*100}%`, top:`${Math.random()*100}%`,
          width:8, height:8, borderRadius:"50%",
          background:["#F59E0B","#7C3AED","#10B981","#EF4444","#ffffff"][i%5],
          animation:`particle${i%4} 1.2s ease-out forwards`,
          opacity:0,
        }}/>
      ))}
      <style>{`
        @keyframes particle0{0%{opacity:1;transform:translate(0,0) scale(1)}100%{opacity:0;transform:translate(-60px,-80px) scale(0)}}
        @keyframes particle1{0%{opacity:1;transform:translate(0,0) scale(1)}100%{opacity:0;transform:translate(60px,-80px) scale(0)}}
        @keyframes particle2{0%{opacity:1;transform:translate(0,0) scale(1)}100%{opacity:0;transform:translate(-40px,60px) scale(0)}}
        @keyframes particle3{0%{opacity:1;transform:translate(0,0) scale(1)}100%{opacity:0;transform:translate(40px,60px) scale(0)}}
      `}</style>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════

const INITIAL_STATS = {
  totalXp:0, level:1,
  totalMissions:0, streak:0,
  lastTrainedDay:null, lastTrainedWeek:null,
  totalFlexoes:0, totalAgacham:0, totalPrancha:0,
  maxDayMissions:0, dayMissions:0, todayKey:null,
  perfectWeeks:0,
  unlockedAchievements:[],
  completedMissions:{},   // id -> { count, progress }
  weeklyProgress:{},      // id -> count
};

export default function FitnessRPGv2() {
  const { canInstall, isOnline, updateAvailable, promptInstall, applyUpdate } = usePWA();

  // Remover splash nativo quando o componente montar
  useEffect(() => { if (window.__hideSplash) window.__hideSplash(); }, []);
  const [tab, setTab]           = useState("home");
  const [stats, setStats]       = useState(INITIAL_STATS);
  const [activeMission, setActiveMission] = useState(null); // mission being done
  const [missionProgress, setMissionProgress] = useState(0);
  const [missionTimer, setMissionTimer]     = useState(0);
  const [timerRunning, setTimerRunning]     = useState(false);
  const [notification, setNotification]     = useState(null); // {msg, color, icon}
  const [particles, setParticles]           = useState(false);
  const [levelUpAnim, setLevelUpAnim]       = useState(false);
  const [rankTab, setRankTab]               = useState("regional");
  const [achievementFlash, setAchievementFlash] = useState(null);

  const timerRef = useRef(null);
  const missionRef = useRef(null);

  // ── notify ──
  function notify(msg, color="#7C3AED", icon="⚡") {
    setNotification({msg,color,icon});
    setTimeout(()=>setNotification(null),2800);
  }

  // ── check achievements ──
  function checkAchievements(newStats) {
    const unlocked = [...(newStats.unlockedAchievements||[])];
    ACHIEVEMENTS.forEach(a=>{
      if (!unlocked.includes(a.id) && a.condition(newStats)) {
        unlocked.push(a.id);
        setAchievementFlash({title:a.title,icon:a.icon});
        setTimeout(()=>setAchievementFlash(null),3000);
      }
    });
    return unlocked;
  }

  // ── complete mission ──
  function completeMission(mission) {
    setStats(prev=>{
      const today = todayKey();
      const isSameDay = prev.todayKey===today;
      const dayMissions = isSameDay ? prev.dayMissions+1 : 1;
      const lastDay = prev.lastTrainedDay;
      const yest = new Date(Date.now()-86400000).toDateString();
      const streak = lastDay===new Date().toDateString() ? prev.streak :
                     lastDay===yest ? prev.streak+1 : 1;

      // Weekly
      const thisWeek = weekKey();
      const weeklyProgress = prev.lastTrainedWeek===thisWeek ? {...prev.weeklyProgress} : {};
      weeklyProgress[mission.id] = (weeklyProgress[mission.id]||0)+1;

      // XP
      const newXp = prev.totalXp + mission.xp;
      const prevLvl = getLevelFromXp(prev.totalXp).level;
      const newLvlInfo = getLevelFromXp(newXp);
      const leveled = newLvlInfo.level > prevLvl;

      // Counters
      const totalFlexoes = mission.category==="força"&&mission.unit==="flexões"
        ? prev.totalFlexoes+(mission.target||0) : prev.totalFlexoes;
      const totalAgacham = mission.unit==="agacham."
        ? prev.totalAgacham+(mission.target||0) : prev.totalAgacham;
      const totalPrancha = mission.unit==="segundos"&&mission.category==="core"
        ? prev.totalPrancha+(mission.target||0) : prev.totalPrancha;

      const completedMissions = {
        ...prev.completedMissions,
        [mission.id]:{ count:(prev.completedMissions[mission.id]?.count||0)+1 }
      };

      const next = {
        ...prev,
        totalXp:newXp, level:newLvlInfo.level,
        totalMissions:prev.totalMissions+1,
        streak, lastTrainedDay:new Date().toDateString(),
        lastTrainedWeek:thisWeek,
        todayKey:today, dayMissions,
        maxDayMissions:Math.max(prev.maxDayMissions, dayMissions),
        weeklyProgress, completedMissions,
        totalFlexoes, totalAgacham, totalPrancha,
      };
      next.unlockedAchievements = checkAchievements(next);

      if (leveled) {
        setTimeout(()=>{ setLevelUpAnim(true); setTimeout(()=>setLevelUpAnim(false),2500); },300);
        setTimeout(()=>setParticles(true),200);
        setTimeout(()=>setParticles(false),1500);
        notify(`🎉 LEVEL UP! Nível ${newLvlInfo.level}!`, "#F59E0B","🏆");
      } else {
        setParticles(true); setTimeout(()=>setParticles(false),1200);
        notify(`✅ +${mission.xp} XP conquistado!`, "#10B981","⭐");
      }

      return next;
    });
  }

  // ── start mission ──
  function startMission(m) {
    setActiveMission(m);
    setMissionProgress(0);
    setMissionTimer(0);
    setTimerRunning(false);
    clearInterval(timerRef.current);
    missionRef.current = false;
    if (m.unit==="segundos") {
      setTimerRunning(true);
      timerRef.current = setInterval(()=>setMissionTimer(t=>t+1),1000);
    }
  }

  function addProgress() {
    if (!activeMission) return;
    const next = missionProgress+1;
    setMissionProgress(next);
    if (next>=activeMission.target) finishMission();
  }

  function finishMission() {
    if (missionRef.current) return;
    missionRef.current = true;
    clearInterval(timerRef.current);
    completeMission(activeMission);
    setActiveMission(null);
  }

  useEffect(()=>{
    if (!timerRunning||!activeMission) return;
    if (missionTimer>=activeMission.target) {
      setTimerRunning(false);
      clearInterval(timerRef.current);
      finishMission();
    }
  },[missionTimer]);

  useEffect(()=>()=>clearInterval(timerRef.current),[]);

  const lvlInfo = getLevelFromXp(stats.totalXp);

  // ── Styles ──────────────────────────────────────────────
  const C = {
    bg:"#0B0C1A", card:"#12132A", cardBorder:"#1E2040",
    purple:"#7C3AED", gold:"#F59E0B", green:"#10B981",
    red:"#EF4444", blue:"#3B82F6", pink:"#EC4899",
    text:"#E2E8F0", muted:"#6B7280",
  };

  const css = `
    *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
    ::-webkit-scrollbar{width:4px;background:#0B0C1A}
    ::-webkit-scrollbar-thumb{background:#1E2040;border-radius:4px}
    @keyframes floatUp{0%{opacity:1;transform:translateY(0)}100%{opacity:0;transform:translateY(-60px)}}
    @keyframes slideUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
    @keyframes popIn{from{opacity:0;transform:scale(0.7)}to{opacity:1;transform:scale(1)}}
    @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}
    @keyframes glow{0%,100%{box-shadow:0 0 12px #7C3AED44}50%{box-shadow:0 0 28px #7C3AEDaa}}
    @keyframes shimmer{0%,100%{opacity:.7}50%{opacity:1}}
    @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
    @keyframes levelUp{0%{transform:scale(1);opacity:1}50%{transform:scale(1.15);opacity:1}100%{transform:scale(1);opacity:1}}
    @keyframes slideInRight{from{opacity:0;transform:translateX(30px)}to{opacity:1;transform:translateX(0)}}
    @keyframes achievementPop{0%{opacity:0;transform:translateY(-20px) scale(0.8)}20%{opacity:1;transform:translateY(0) scale(1)}80%{opacity:1;transform:translateY(0)}100%{opacity:0;transform:translateY(-10px)}}
  `;

  const appStyle = {
    minHeight:"100vh", background:C.bg, color:C.text,
    fontFamily:"'Segoe UI',system-ui,-apple-system,sans-serif",
    maxWidth:480, margin:"0 auto", position:"relative",
    paddingBottom:80,
  };

  const cardStyle = (extra={}) => ({
    background:C.card, border:`1px solid ${C.cardBorder}`,
    borderRadius:20, padding:"18px", marginBottom:12,
    ...extra,
  });

  const btn = (color=C.purple, small=false) => ({
    background:`linear-gradient(135deg,${color},${color}cc)`,
    border:`1px solid ${color}88`, borderRadius:14,
    padding:small?"10px 18px":"14px 20px",
    color:"#fff", fontWeight:800, fontSize:small?13:15,
    cursor:"pointer", width:"100%",
    boxShadow:`0 4px 20px ${color}33`,
    fontFamily:"inherit", letterSpacing:0.3,
    transition:"transform 0.1s, box-shadow 0.2s",
  });

  // ════════════════════════════════════════════════════════
  // ACTIVE MISSION OVERLAY
  // ════════════════════════════════════════════════════════
  if (activeMission) {
    const m = activeMission;
    const isTimer = m.unit==="segundos";
    const progress = Math.min(1,(isTimer?missionTimer:missionProgress)/m.target);
    const circ = 2*Math.PI*80;
    const catColor = CAT_COLORS[m.category]||C.purple;

    return (
      <div style={appStyle}>
        <style>{css}</style>
        <div style={{ padding:"30px 20px", textAlign:"center" }}>
          <div style={{ fontSize:12, color:catColor, fontWeight:800, letterSpacing:2, marginBottom:8 }}>MISSÃO ATIVA</div>
          <div style={{ fontSize:28, fontWeight:900, color:C.text, marginBottom:4 }}>{m.title}</div>
          <div style={{ color:C.muted, fontSize:14, marginBottom:8 }}>{m.desc}</div>
          <Badge diff={m.diff}/>

          {/* Ring */}
          <div style={{ position:"relative", width:200, height:200, margin:"28px auto" }}>
            <svg width="200" height="200" style={{ position:"absolute", inset:0, transform:"rotate(-90deg)" }}>
              <circle cx="100" cy="100" r="80" fill="none" stroke="#1a1b3a" strokeWidth="14"/>
              <circle cx="100" cy="100" r="80" fill="none" stroke={catColor} strokeWidth="14"
                strokeDasharray={circ} strokeDashoffset={circ*(1-progress)}
                strokeLinecap="round"
                style={{ transition:"stroke-dashoffset 0.35s ease", filter:`drop-shadow(0 0 10px ${catColor})` }}/>
            </svg>
            <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
              <div style={{ fontSize:52, marginBottom:4 }}>{m.icon}</div>
              <div style={{ fontSize:38, fontWeight:900, color:catColor }}>{isTimer?missionTimer:missionProgress}</div>
              <div style={{ fontSize:14, color:C.muted }}>/ {m.target} {m.unit}</div>
            </div>
          </div>

          {/* Instrução */}
          <div style={{ ...cardStyle(), textAlign:"left", marginBottom:20 }}>
            <div style={{ fontWeight:800, marginBottom:8, color:C.text }}>📋 Como executar</div>
            <div style={{ fontSize:13, color:C.muted, lineHeight:1.7 }}>
              {m.category==="força"&&"Mantenha a postura correta. Respire: expire no esforço, inspire na descida. Qualidade > velocidade."}
              {m.category==="core"&&"Ative o core, respire normalmente, não trave a respiração. Mantenha o corpo alinhado."}
              {m.category==="cardio"&&"Mantenha um ritmo constante. Se ficar ofegante, reduza a intensidade mas não pare."}
              {m.category==="fullbody"&&"Movimento completo e controlado. Faça uma pausa se precisar — qualidade é prioridade."}
            </div>
          </div>

          {isTimer ? (
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
              <button onClick={()=>{clearInterval(timerRef.current);setTimerRunning(false);}} style={btn("#EF4444")}>⏸ Pausar</button>
              <button onClick={()=>{if(!timerRunning){setTimerRunning(true);timerRef.current=setInterval(()=>setMissionTimer(t=>t+1),1000);}}} style={btn(C.green)}>▶ Continuar</button>
            </div>
          ) : (
            <button onClick={addProgress} style={{ ...btn(catColor), fontSize:20, padding:"22px", animation:"pulse 1.5s ease-in-out infinite", marginBottom:12 }}>
              {m.icon} +1 {m.unit.slice(0,-1)||"rep"}
            </button>
          )}
          <button onClick={()=>{clearInterval(timerRef.current);setActiveMission(null);}} style={{ background:"none",border:"1px solid #1E2040",borderRadius:12,color:C.muted,padding:"10px",cursor:"pointer",width:"100%",fontFamily:"inherit",fontSize:13 }}>
            Cancelar missão
          </button>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════
  // MISSION CARD
  // ════════════════════════════════════════════════════════
  function MissionCard({ m, compact=false }) {
    const done = (stats.completedMissions[m.id]?.count||0)>0 && m.once;
    const catColor = CAT_COLORS[m.category]||C.purple;
    const completedToday = stats.todayKey===todayKey() &&
      (stats.completedMissions[m.id]?.count||0)>0;

    return (
      <div style={{ ...cardStyle(), border:`1px solid ${done?"#10B98133":C.cardBorder}`, opacity:done?0.6:1, animation:"slideUp 0.3s ease" }}>
        <div style={{ display:"flex", gap:14, alignItems:"flex-start" }}>
          <div style={{ fontSize:36, filter:`drop-shadow(0 0 8px ${catColor})`, flexShrink:0 }}>{m.icon}</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:4 }}>
              <div style={{ fontWeight:900, fontSize:15, color:C.text, lineHeight:1.2 }}>{m.title}</div>
              <div style={{ fontSize:13, color:C.gold, fontWeight:800, flexShrink:0, marginLeft:8 }}>+{m.xp} XP</div>
            </div>
            <div style={{ fontSize:12, color:C.muted, marginBottom:8 }}>{m.desc}</div>
            <div style={{ display:"flex", gap:8, alignItems:"center" }}>
              <Badge diff={m.diff}/>
              <span style={{ fontSize:10, color:catColor, fontWeight:700 }}>
                {m.category==="força"?"💪":m.category==="core"?"🔥":m.category==="cardio"?"⚡":"🏋️"} {m.category}
              </span>
              {done && <span style={{ fontSize:10, color:C.green, fontWeight:700 }}>✅ concluída</span>}
            </div>
          </div>
        </div>
        {!done && (
          <button onClick={()=>startMission(m)} style={{ ...btn(catColor,true), marginTop:12 }}>
            {completedToday?"🔄 Fazer novamente":"⚡ Iniciar missão"}
          </button>
        )}
      </div>
    );
  }

  // ════════════════════════════════════════════════════════
  // HOME TAB
  // ════════════════════════════════════════════════════════
  function HomeTab() {
    const lvl = getLevelFromXp(stats.totalXp);
    const todayDone = stats.todayKey===todayKey() ? stats.dayMissions : 0;
    const recentMissions = DAILY_MISSIONS.slice(0,3);

    return (
      <div style={{ padding:"20px 16px 0" }}>
        {/* Header hero */}
        <div style={{ ...cardStyle({ background:"linear-gradient(135deg,#1a0a35,#0f1a35)", border:"1px solid #7C3AED33", marginBottom:16 }) }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:12, color:C.purple, fontWeight:800, letterSpacing:2, marginBottom:4 }}>⚔️ BEM-VINDO DE VOLTA</div>
              <div style={{ fontSize:24, fontWeight:900, color:C.text, marginBottom:4 }}>Guerreiro</div>
              <div style={{ display:"flex", gap:16, marginBottom:12 }}>
                <div><div style={{ fontSize:10, color:C.muted }}>🔥 Sequência</div><div style={{ fontWeight:900, color:C.gold, fontSize:18 }}>{stats.streak}d</div></div>
                <div><div style={{ fontSize:10, color:C.muted }}>🎯 Hoje</div><div style={{ fontWeight:900, color:C.green, fontSize:18 }}>{todayDone}</div></div>
                <div><div style={{ fontSize:10, color:C.muted }}>🏆 Total</div><div style={{ fontWeight:900, color:C.blue, fontSize:18 }}>{stats.totalMissions}</div></div>
              </div>
              <div style={{ marginBottom:4 }}>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:11, color:C.muted, marginBottom:4 }}>
                  <span>XP {lvl.xpInLevel}/{lvl.xpNeeded}</span>
                  <span>{Math.floor((lvl.xpInLevel/lvl.xpNeeded)*100)}%</span>
                </div>
                <ProgressBar value={lvl.xpInLevel} max={lvl.xpNeeded}/>
              </div>
            </div>
            <div style={{ marginLeft:20 }}>
              <XPRing xpInLevel={lvl.xpInLevel} xpNeeded={lvl.xpNeeded} level={lvl.level} size={90}
                style={{ animation: levelUpAnim?"levelUp 0.6s ease":undefined }}/>
            </div>
          </div>
        </div>

        {/* Streak banner */}
        {stats.streak>=3 && (
          <div style={{ ...cardStyle({ background:"linear-gradient(90deg,#1a0a00,#1a1000)", border:"1px solid #F59E0B44", textAlign:"center" }) }}>
            <div style={{ fontSize:24 }}>🔥</div>
            <div style={{ fontWeight:900, color:C.gold, fontSize:16 }}>{stats.streak} dias em chamas!</div>
            <div style={{ fontSize:12, color:C.muted }}>Continue assim para conquistas épicas</div>
          </div>
        )}

        {/* Missões do dia */}
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", margin:"4px 0 10px" }}>
          <div style={{ fontSize:14, fontWeight:800, color:C.text }}>⚡ Missões de Hoje</div>
          <button onClick={()=>setTab("missions")} style={{ background:"none",border:"none",color:C.purple,fontSize:12,cursor:"pointer",fontFamily:"inherit",fontWeight:700 }}>Ver todas →</button>
        </div>
        {recentMissions.map(m=><MissionCard key={m.id} m={m}/>)}

        {/* Conquista recente */}
        {stats.unlockedAchievements.length>0 && (
          <>
            <div style={{ fontSize:14, fontWeight:800, color:C.text, margin:"8px 0 10px" }}>🏅 Conquistas</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
              {stats.unlockedAchievements.slice(-2).map(id=>{
                const a=ACHIEVEMENTS.find(a=>a.id===id);
                if(!a) return null;
                return (
                  <div key={id} style={{ background:"linear-gradient(135deg,#0f1a10,#111a11)", border:"1px solid #10B98144", borderRadius:16, padding:"12px", textAlign:"center" }}>
                    <div style={{ fontSize:28, marginBottom:4 }}>{a.icon}</div>
                    <div style={{ fontSize:12, fontWeight:800, color:C.green }}>{a.title}</div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>
    );
  }

  // ════════════════════════════════════════════════════════
  // MISSIONS TAB
  // ════════════════════════════════════════════════════════
  function MissionsTab() {
    const [mTab, setMTab] = useState("daily");
    const tabs = [["daily","Diárias","📋"],["weekly","Semanais","📅"],["special","Especiais","⭐"]];
    const allMissions = { daily:DAILY_MISSIONS, weekly:WEEKLY_MISSIONS, special:SPECIAL_MISSIONS };

    return (
      <div style={{ padding:"20px 16px 0" }}>
        <div style={{ fontSize:20, fontWeight:900, color:C.text, marginBottom:16 }}>🎯 Missões</div>

        {/* Tab selector */}
        <div style={{ display:"flex", gap:8, marginBottom:16 }}>
          {tabs.map(([id,label,ico])=>(
            <button key={id} onClick={()=>setMTab(id)} style={{
              flex:1, background:mTab===id?C.purple:"#12132A",
              border:`1px solid ${mTab===id?C.purple:C.cardBorder}`, borderRadius:12,
              color:mTab===id?"#fff":C.muted, padding:"8px 4px", fontWeight:700, fontSize:12,
              cursor:"pointer", fontFamily:"inherit"
            }}>{ico} {label}</button>
          ))}
        </div>

        {/* Stats bar */}
        <div style={{ ...cardStyle({ display:"flex", justifyContent:"space-around", textAlign:"center", padding:"12px" }) }}>
          {[["📋","Diárias",DAILY_MISSIONS.filter(m=>stats.completedMissions[m.id]?.count>0).length+"/"+DAILY_MISSIONS.length],
            ["📅","Semanais",WEEKLY_MISSIONS.filter(m=>stats.completedMissions[m.id]?.count>0).length+"/"+WEEKLY_MISSIONS.length],
            ["⭐","Especiais",SPECIAL_MISSIONS.filter(m=>stats.completedMissions[m.id]?.count>0).length+"/"+SPECIAL_MISSIONS.length]
          ].map(([ico,lbl,val])=>(
            <div key={lbl}>
              <div style={{ fontSize:16 }}>{ico}</div>
              <div style={{ fontSize:17, fontWeight:900, color:C.gold }}>{val}</div>
              <div style={{ fontSize:10, color:C.muted }}>{lbl}</div>
            </div>
          ))}
        </div>

        {allMissions[mTab].map(m=><MissionCard key={m.id} m={m}/>)}
      </div>
    );
  }

  // ════════════════════════════════════════════════════════
  // ACHIEVEMENTS TAB
  // ════════════════════════════════════════════════════════
  function AchievementsTab() {
    const lvl = getLevelFromXp(stats.totalXp);
    const unlocked = stats.unlockedAchievements;
    const pct = Math.floor((unlocked.length/ACHIEVEMENTS.length)*100);

    return (
      <div style={{ padding:"20px 16px 0" }}>
        <div style={{ fontSize:20, fontWeight:900, color:C.text, marginBottom:4 }}>🏅 Conquistas</div>
        <div style={{ fontSize:13, color:C.muted, marginBottom:16 }}>{unlocked.length}/{ACHIEVEMENTS.length} desbloqueadas</div>

        {/* Progress */}
        <div style={{ ...cardStyle({ marginBottom:16 }) }}>
          <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, color:C.muted, marginBottom:6 }}>
            <span>Progresso geral</span><span style={{ color:C.gold, fontWeight:700 }}>{pct}%</span>
          </div>
          <ProgressBar value={unlocked.length} max={ACHIEVEMENTS.length} color={C.gold}/>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8, marginTop:14 }}>
            {[["🎯","Missões",stats.totalMissions],["🔥","Sequência",stats.streak+"d"],["⭐","Nível",lvl.level]].map(([ico,lbl,val])=>(
              <div key={lbl} style={{ background:"#0a0a1e", borderRadius:12, padding:"10px 8px", textAlign:"center" }}>
                <div style={{ fontSize:18 }}>{ico}</div>
                <div style={{ fontSize:17, fontWeight:900, color:C.gold }}>{val}</div>
                <div style={{ fontSize:10, color:C.muted }}>{lbl}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievement grid */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
          {ACHIEVEMENTS.map(a=>{
            const isUnlocked = unlocked.includes(a.id);
            return (
              <div key={a.id} style={{
                background: isUnlocked?"linear-gradient(135deg,#0f1f0f,#131f13)":"#0d0d1a",
                border:`1px solid ${isUnlocked?"#10B98144":C.cardBorder}`,
                borderRadius:16, padding:"14px 12px", textAlign:"center",
                opacity:isUnlocked?1:0.5,
                filter:isUnlocked?"none":"grayscale(1)",
                transition:"all 0.3s"
              }}>
                <div style={{ fontSize:32, marginBottom:6, filter:isUnlocked?`drop-shadow(0 0 8px ${C.green})`:"none" }}>{a.icon}</div>
                <div style={{ fontSize:12, fontWeight:900, color:isUnlocked?C.green:C.muted, marginBottom:4 }}>{a.title}</div>
                <div style={{ fontSize:10, color:C.muted, lineHeight:1.4 }}>{a.desc}</div>
                {isUnlocked && <div style={{ fontSize:10, color:C.green, fontWeight:700, marginTop:6 }}>✅ Desbloqueada</div>}
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════
  // RANKING TAB
  // ════════════════════════════════════════════════════════
  function RankingTab() {
    const tabs = [["regional","🏙️ Regional"],["nacional","🇧🇷 Nacional"],["mundial","🌍 Mundial"]];
    const list = RANKING_DATA[rankTab];

    // Insert player
    const lvlInfo = getLevelFromXp(stats.totalXp);
    const playerEntry = { name:"Você", level:lvlInfo.level, xp:stats.totalXp, missions:stats.totalMissions, avatar:"🧙", isPlayer:true };
    const allEntries = [...list, playerEntry].sort((a,b)=>b.xp-a.xp);
    const playerRank = allEntries.findIndex(e=>e.isPlayer)+1;

    return (
      <div style={{ padding:"20px 16px 0" }}>
        <div style={{ fontSize:20, fontWeight:900, color:C.text, marginBottom:16 }}>🏆 Ranking</div>

        {/* Tab selector */}
        <div style={{ display:"flex", gap:6, marginBottom:16 }}>
          {tabs.map(([id,label])=>(
            <button key={id} onClick={()=>setRankTab(id)} style={{
              flex:1, background:rankTab===id?C.purple:"#12132A",
              border:`1px solid ${rankTab===id?C.purple:C.cardBorder}`, borderRadius:12,
              color:rankTab===id?"#fff":C.muted, padding:"8px 4px", fontWeight:700, fontSize:11,
              cursor:"pointer", fontFamily:"inherit"
            }}>{label}</button>
          ))}
        </div>

        {/* Minha posição */}
        <div style={{ ...cardStyle({ background:"linear-gradient(135deg,#1a0a35,#0a1035)", border:"1px solid #7C3AED66", marginBottom:16 }) }}>
          <div style={{ fontSize:11, color:C.purple, fontWeight:800, marginBottom:8 }}>SUA POSIÇÃO</div>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <div style={{ fontSize:32, fontWeight:900, color:C.gold }}>#{playerRank}</div>
            <div style={{ fontSize:32 }}>🧙</div>
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:900, color:C.text }}>Você</div>
              <div style={{ fontSize:12, color:C.muted }}>Nível {lvlInfo.level} • {stats.totalXp.toLocaleString()} XP</div>
            </div>
            <div style={{ textAlign:"right" }}>
              <div style={{ fontSize:16, fontWeight:900, color:C.green }}>{stats.totalMissions}</div>
              <div style={{ fontSize:10, color:C.muted }}>missões</div>
            </div>
          </div>
        </div>

        {/* Lista */}
        {allEntries.slice(0,10).map((entry,i)=>{
          const rankColor = i===0?"#FFD700":i===1?"#C0C0C0":i===2?"#CD7F32":C.muted;
          const isPlayer = entry.isPlayer;
          return (
            <div key={entry.name+i} style={{
              ...cardStyle({
                display:"flex", alignItems:"center", gap:12, padding:"14px 16px",
                background:isPlayer?"linear-gradient(90deg,#1a0a35,#0a1035)":C.card,
                border:`1px solid ${isPlayer?"#7C3AED66":C.cardBorder}`,
              })
            }}>
              <div style={{ fontSize:20, fontWeight:900, color:rankColor, width:28, textAlign:"center" }}>
                {i===0?"🥇":i===1?"🥈":i===2?"🥉":`#${i+1}`}
              </div>
              <div style={{ fontSize:26 }}>{entry.avatar}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:800, color:isPlayer?C.purple:C.text, fontSize:14 }}>
                  {entry.name}{isPlayer?" (você)":""}
                </div>
                <div style={{ fontSize:11, color:C.muted }}>Nível {entry.level} • {entry.missions} missões</div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontSize:14, fontWeight:900, color:C.gold }}>{entry.xp.toLocaleString()}</div>
                <div style={{ fontSize:10, color:C.muted }}>XP</div>
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  // ════════════════════════════════════════════════════════
  // PROFILE TAB
  // ════════════════════════════════════════════════════════
  function ProfileTab() {
    const lvl = getLevelFromXp(stats.totalXp);
    const unlocked = stats.unlockedAchievements;
    const nextLvlXp = lvl.xpNeeded - lvl.xpInLevel;

    return (
      <div style={{ padding:"20px 16px 0" }}>
        {/* Profile hero */}
        <div style={{ ...cardStyle({ background:"linear-gradient(135deg,#1a0a35,#0f1a35)", border:"1px solid #7C3AED44", textAlign:"center", marginBottom:16 }) }}>
          <div style={{ display:"flex", justifyContent:"center", marginBottom:12 }}>
            <XPRing xpInLevel={lvl.xpInLevel} xpNeeded={lvl.xpNeeded} level={lvl.level} size={110}/>
          </div>
          <div style={{ fontSize:22, fontWeight:900, color:C.text, marginBottom:2 }}>Guerreiro</div>
          <div style={{ fontSize:13, color:C.purple, fontWeight:700, marginBottom:12 }}>
            {lvl.level<5?"Iniciante":lvl.level<10?"Aprendiz":lvl.level<20?"Veterano":lvl.level<35?"Elite":"Lendário"}
          </div>
          <div style={{ fontSize:12, color:C.muted, marginBottom:6 }}>
            {lvl.xpInLevel.toLocaleString()} / {lvl.xpNeeded.toLocaleString()} XP para Nível {lvl.level+1}
          </div>
          <ProgressBar value={lvl.xpInLevel} max={lvl.xpNeeded}/>
          <div style={{ fontSize:11, color:C.muted, marginTop:6 }}>Faltam {nextLvlXp.toLocaleString()} XP</div>
        </div>

        {/* Stats grid */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:14 }}>
          {[
            ["🎯","Missões Totais",stats.totalMissions,C.purple],
            ["🔥","Maior Sequência",stats.streak+"d",C.gold],
            ["⭐","XP Total",stats.totalXp.toLocaleString(),C.blue],
            ["🏅","Conquistas",unlocked.length+"/"+ACHIEVEMENTS.length,C.green],
            ["💪","Flexões",stats.totalFlexoes,C.red],
            ["🦵","Agacham.",stats.totalAgacham,"#f97316"],
            ["🔥","Prancha",Math.floor(stats.totalPrancha/60)+"min",C.gold],
            ["🏆","Melhor Dia",stats.maxDayMissions+" missões",C.pink],
          ].map(([ico,lbl,val,c])=>(
            <div key={lbl} style={{ background:"#0d0d20", border:`1px solid ${c}22`, borderRadius:16, padding:"14px 12px", textAlign:"center" }}>
              <div style={{ fontSize:22 }}>{ico}</div>
              <div style={{ fontSize:20, fontWeight:900, color:c, margin:"4px 0 2px" }}>{val}</div>
              <div style={{ fontSize:11, color:C.muted }}>{lbl}</div>
            </div>
          ))}
        </div>

        {/* Rank badge */}
        <div style={{ ...cardStyle({ textAlign:"center", background:"linear-gradient(135deg,#1a1000,#0a0a1a)", border:"1px solid #F59E0B44" }) }}>
          <div style={{ fontSize:40 }}>
            {lvl.level<5?"🟤":lvl.level<10?"⚪":lvl.level<20?"🟡":lvl.level<35?"🔵":"💎"}
          </div>
          <div style={{ fontWeight:900, color:C.gold, fontSize:18, marginTop:6 }}>
            {lvl.level<5?"Bronze":lvl.level<10?"Prata":lvl.level<20?"Ouro":lvl.level<35?"Diamante":"Lendário"}
          </div>
          <div style={{ fontSize:12, color:C.muted }}>Rank atual</div>
        </div>

        {/* Conquistas recentes */}
        {unlocked.length>0 && (
          <>
            <div style={{ fontSize:14, fontWeight:800, color:C.text, margin:"16px 0 10px" }}>🏅 Conquistas recentes</div>
            {unlocked.slice(-3).reverse().map(id=>{
              const a=ACHIEVEMENTS.find(a=>a.id===id); if(!a) return null;
              return (
                <div key={id} style={{ ...cardStyle({ display:"flex", gap:12, alignItems:"center", padding:"12px 16px", border:"1px solid #10B98133" }) }}>
                  <div style={{ fontSize:28, filter:`drop-shadow(0 0 8px ${C.green})` }}>{a.icon}</div>
                  <div><div style={{ fontWeight:800, color:C.green, fontSize:14 }}>{a.title}</div><div style={{ fontSize:12, color:C.muted }}>{a.desc}</div></div>
                </div>
              );
            })}
          </>
        )}
      </div>
    );
  }

  // ════════════════════════════════════════════════════════
  // RENDER
  // ════════════════════════════════════════════════════════
  const NAV = [
    { id:"home",     label:"Início",    icon:"🏠" },
    { id:"missions", label:"Missões",   icon:"🎯" },
    { id:"achievements",label:"Conquistas",icon:"🏅"},
    { id:"ranking",  label:"Ranking",   icon:"🏆" },
    { id:"profile",  label:"Perfil",    icon:"👤" },
  ];

  return (
    <div style={appStyle}>
      <style>{css}</style>

      {/* Particles */}
      <Particles active={particles}/>

      {/* Notification toast */}
      {notification && (
        <div style={{ position:"fixed", top:20, left:"50%", transform:"translateX(-50%)",
          background:"#1a1b3a", border:`1px solid ${notification.color}66`,
          borderRadius:20, padding:"12px 20px", zIndex:1000, maxWidth:320, width:"90%",
          boxShadow:`0 8px 32px ${notification.color}44`,
          animation:"achievementPop 2.8s ease forwards",
          display:"flex", alignItems:"center", gap:10
        }}>
          <span style={{ fontSize:20 }}>{notification.icon}</span>
          <span style={{ fontWeight:800, color:notification.color, fontSize:14 }}>{notification.msg}</span>
        </div>
      )}

      {/* Achievement flash */}
      {achievementFlash && (
        <div style={{ position:"fixed", top:70, left:"50%", transform:"translateX(-50%)",
          background:"linear-gradient(135deg,#0f1f0f,#131f13)",
          border:"1px solid #10B98166", borderRadius:20, padding:"12px 20px", zIndex:1000,
          boxShadow:`0 8px 32px #10B98144`, animation:"achievementPop 3s ease forwards",
          display:"flex", alignItems:"center", gap:10, maxWidth:300, width:"90%"
        }}>
          <span style={{ fontSize:28 }}>{achievementFlash.icon}</span>
          <div>
            <div style={{ fontSize:10, color:C.green, fontWeight:800, letterSpacing:1 }}>CONQUISTA DESBLOQUEADA!</div>
            <div style={{ fontSize:14, fontWeight:900, color:C.text }}>{achievementFlash.title}</div>
          </div>
        </div>
      )}

      {/* Level up overlay */}
      {levelUpAnim && (
        <div style={{ position:"fixed", inset:0, background:"#00000088", zIndex:998, display:"flex", alignItems:"center", justifyContent:"center" }}>
          <div style={{ textAlign:"center", animation:"popIn 0.4s ease" }}>
            <div style={{ fontSize:80, animation:"spin 1s ease" }}>⭐</div>
            <div style={{ fontSize:36, fontWeight:900, color:C.gold }}>LEVEL UP!</div>
            <div style={{ fontSize:52, fontWeight:900, color:"#fff" }}>Nível {getLevelFromXp(stats.totalXp).level}</div>
          </div>
        </div>
      )}

      {/* Content */}
      <div style={{ overflowY:"auto", height:"calc(100vh - 70px)" }}>
        {tab==="home"         && <HomeTab/>}
        {tab==="missions"     && <MissionsTab/>}
        {tab==="achievements" && <AchievementsTab/>}
        {tab==="ranking"      && <RankingTab/>}
        {tab==="profile"      && <ProfileTab/>}
      </div>

      {/* ── Banners PWA ──────────────────────────────────── */}
      {!isOnline && (
        <div style={{ position:"fixed", top:0, left:"50%", transform:"translateX(-50%)", width:"100%", maxWidth:480, background:"#1a0a0a", borderBottom:"2px solid #EF4444", padding:"8px 16px", zIndex:2000, display:"flex", alignItems:"center", gap:8 }}>
          <span style={{ fontSize:16 }}>📡</span>
          <span style={{ fontSize:13, color:"#FCA5A5", fontWeight:700 }}>Sem conexão — modo offline ativo</span>
        </div>
      )}
      {updateAvailable && (
        <div style={{ position:"fixed", top:0, left:"50%", transform:"translateX(-50%)", width:"100%", maxWidth:480, background:"#0f172a", borderBottom:"2px solid #7C3AED", padding:"8px 16px", zIndex:2000, display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <span style={{ fontSize:13, color:"#C4B5FD", fontWeight:700 }}>🔄 Nova versão disponível!</span>
          <button onClick={applyUpdate} style={{ background:"#7C3AED", border:"none", borderRadius:8, color:"#fff", padding:"4px 12px", fontSize:12, fontWeight:800, cursor:"pointer" }}>Atualizar</button>
        </div>
      )}
      {canInstall && (
        <div style={{ position:"fixed", bottom:80, left:"50%", transform:"translateX(-50%)", width:"calc(100% - 32px)", maxWidth:448, background:"linear-gradient(135deg,#1a0a35,#0a1035)", border:"1px solid #7C3AED66", borderRadius:16, padding:"12px 16px", zIndex:1500, display:"flex", alignItems:"center", justifyContent:"space-between", boxShadow:"0 8px 32px #7C3AED44" }}>
          <div>
            <div style={{ fontSize:13, fontWeight:900, color:"#E2E8F0" }}>📲 Instalar Fitness RPG</div>
            <div style={{ fontSize:11, color:"#6B7280" }}>Acesso rápido, funciona offline</div>
          </div>
          <button onClick={promptInstall} style={{ background:"#7C3AED", border:"none", borderRadius:10, color:"#fff", padding:"8px 14px", fontSize:12, fontWeight:800, cursor:"pointer", whiteSpace:"nowrap" }}>Instalar</button>
        </div>
      )}

      {/* Bottom Nav */}
      <div style={{
        position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)",
        width:"100%", maxWidth:480,
        background:"#0d0e1e", borderTop:"1px solid #1E2040",
        display:"flex", height:70, zIndex:100,
        backdropFilter:"blur(10px)",
      }}>
        {NAV.map(n=>(
          <button key={n.id} onClick={()=>setTab(n.id)} style={{
            flex:1, background:"none", border:"none", cursor:"pointer",
            display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:2,
            color: tab===n.id ? C.purple : C.muted,
            fontFamily:"inherit", transition:"color 0.2s",
            position:"relative",
          }}>
            {tab===n.id && <div style={{ position:"absolute", top:0, left:"20%", right:"20%", height:2, background:C.purple, borderRadius:"0 0 4px 4px", boxShadow:`0 0 8px ${C.purple}` }}/>}
            <span style={{ fontSize:tab===n.id?22:20, transition:"font-size 0.2s" }}>{n.icon}</span>
            <span style={{ fontSize:10, fontWeight:tab===n.id?800:500 }}>{n.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
