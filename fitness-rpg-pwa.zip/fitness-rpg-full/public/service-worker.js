// ═══════════════════════════════════════════════════════════
// Fitness RPG — Service Worker
// Estratégia: Cache-First para assets, Network-First para dados
// ═══════════════════════════════════════════════════════════

const CACHE_NAME = 'fitness-rpg-v2.0.0';
const STATIC_CACHE = 'fitness-rpg-static-v2.0.0';
const DYNAMIC_CACHE = 'fitness-rpg-dynamic-v2.0.0';

// Assets que vão para cache imediatamente no install
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.ico',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  '/icons/icon-144x144.png',
  '/icons/icon-96x96.png',
];

// ── INSTALL: pré-cacheia assets estáticos ──────────────────
self.addEventListener('install', (event) => {
  console.log('[SW] Installing Fitness RPG Service Worker...');
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      console.log('[SW] Pre-caching static assets');
      return cache.addAll(PRECACHE_ASSETS);
    }).then(() => {
      console.log('[SW] Install complete — skipping waiting');
      return self.skipWaiting();
    })
  );
});

// ── ACTIVATE: limpa caches antigos ────────────────────────
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating new Service Worker...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== STATIC_CACHE && name !== DYNAMIC_CACHE)
          .map((name) => {
            console.log('[SW] Deleting old cache:', name);
            return caches.delete(name);
          })
      );
    }).then(() => {
      console.log('[SW] Activation complete — claiming clients');
      return self.clients.claim();
    })
  );
});

// ── FETCH: estratégia híbrida ──────────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Ignora requests não-HTTP (chrome-extension, etc.)
  if (!request.url.startsWith('http')) return;

  // Ignora requisições de analytics/tracking
  if (url.hostname.includes('analytics') || url.hostname.includes('tracking')) return;

  // Navegação (HTML) → Network-First com fallback para cache
  if (request.mode === 'navigate') {
    event.respondWith(networkFirstWithFallback(request));
    return;
  }

  // Assets estáticos (JS, CSS, imagens, fontes) → Cache-First
  if (
    request.destination === 'script' ||
    request.destination === 'style' ||
    request.destination === 'image' ||
    request.destination === 'font' ||
    url.pathname.includes('/icons/') ||
    url.pathname.includes('/static/')
  ) {
    event.respondWith(cacheFirstWithUpdate(request));
    return;
  }

  // Todo o resto → Network-First
  event.respondWith(networkFirstWithFallback(request));
});

// ── Estratégia: Cache-First com atualização em background ──
async function cacheFirstWithUpdate(request) {
  const cache = await caches.open(STATIC_CACHE);
  const cached = await cache.match(request);

  if (cached) {
    // Atualiza o cache em background (stale-while-revalidate)
    fetch(request).then((response) => {
      if (response && response.ok) cache.put(request, response.clone());
    }).catch(() => {});
    return cached;
  }

  // Não está em cache: busca da rede e armazena
  try {
    const response = await fetch(request);
    if (response && response.ok) {
      const dynCache = await caches.open(DYNAMIC_CACHE);
      dynCache.put(request, response.clone());
    }
    return response;
  } catch {
    return new Response('Recurso não disponível offline.', { status: 503 });
  }
}

// ── Estratégia: Network-First com fallback para cache ──────
async function networkFirstWithFallback(request) {
  try {
    const response = await fetch(request);
    if (response && response.ok) {
      const cache = await caches.open(DYNAMIC_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    const cached = await caches.match(request);
    if (cached) return cached;

    // Fallback final: retorna o index.html (SPA fallback)
    if (request.mode === 'navigate') {
      const fallback = await caches.match('/index.html');
      if (fallback) return fallback;
    }

    return new Response(
      JSON.stringify({ error: 'Sem conexão. Dados offline disponíveis.' }),
      { status: 503, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

// ── PUSH NOTIFICATIONS (base para futuras notificações) ────
self.addEventListener('push', (event) => {
  if (!event.data) return;
  const data = event.data.json();
  const options = {
    body: data.body || 'Hora de treinar, Guerreiro!',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/icon-96x96.png',
    tag: 'fitness-rpg-notification',
    renotify: true,
    vibrate: [200, 100, 200],
    data: { url: data.url || '/' },
    actions: [
      { action: 'open',    title: '⚔️ Treinar agora' },
      { action: 'dismiss', title: '✖ Depois'         },
    ],
  };
  event.waitUntil(
    self.registration.showNotification(data.title || '⚔️ Fitness RPG', options)
  );
});

// ── Clique em notificação ──────────────────────────────────
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  if (event.action === 'dismiss') return;
  const url = event.notification.data?.url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url === url && 'focus' in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow(url);
    })
  );
});

// ── SYNC em background (quando voltar online) ──────────────
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-progress') {
    event.waitUntil(syncProgress());
  }
});

async function syncProgress() {
  console.log('[SW] Background sync: syncing progress...');
  // Placeholder para futura sincronização com backend
}

// ── Mensagens do app principal ─────────────────────────────
self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  if (event.data?.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
});
